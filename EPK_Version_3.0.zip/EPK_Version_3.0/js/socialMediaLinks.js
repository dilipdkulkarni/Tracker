// JavaScript Document
/***************socialMediaIcon****************/
$(document).ready(function() {
    $("#blogLink").hover(function() {
        $("#blogLink").fadeOut(500);
        $("#blogHover").fadeIn(500);
    });
});

$(document).ready(function() {
    $("#blogHover").mouseout(function() {
        $("#blogHover").fadeOut(500);
        $("#blogLink").fadeIn(500);
    });
});


$(document).ready(function() {
    $("#fbLink").hover(function() {
        $("#fbLink").fadeOut(500);
        $("#fbHover").fadeIn(500);
    });
});

$(document).ready(function() {
    $("#fbHover").mouseout(function() {
        $("#fbHover").fadeOut(500);
        $("#fbLink").fadeIn(500);
    });
});


$(document).ready(function() {
    $("#twitterLink").hover(function() {
        $("#twitterLink").fadeOut(500);
        $("#twitterHover").fadeIn(500);
    });
});

$(document).ready(function() {
    $("#twitterHover").mouseout(function() {
        $("#twitterHover").fadeOut(500);
        $("#twitterLink").fadeIn(500);
    });
});
/**************slidingPanel**********************/

$(document).ready(function() {
    $(".toggleOpen").click(function() {
        $(".toggleOpen").fadeOut(0);
        $(".toggleClose").fadeIn(0);
    });
});

$(document).ready(function() {
    $(".toggleClose").click(function() {
        $(".toggleClose").fadeOut(0);
        $(".toggleOpen").fadeIn(0);
    });
});


$(document).ready(function() {
    $("#toggleOpen").click(function() {
        $("#toggle1").slideToggle(500);
    });

    $("#toggleClose").click(function() {
        $("#toggle1").slideToggle(500);
    });
});
