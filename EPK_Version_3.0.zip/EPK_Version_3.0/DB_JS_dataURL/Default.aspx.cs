using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using InfoSoftGlobal;
using System.Data.SqlClient;
using DataConnection;

public partial class DB_JS_dataURL_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Literal1.Text = GetFactorySummaryChartHtml();
        Literal2.Text = GetFactoryDetailedChartHtml();
        Literal3.Text = GetFactoryDetailDetailedChartHtml();
    }
    public string GetFactorySummaryChartHtml()
    {
        //xmlData will be used to store the entire XML document generated
        StringBuilder xmlData = new StringBuilder();

        //Generate the chart element
        xmlData.Append("<chart exportEnabled='1' exportAction='Download' exportAtClient='0' exportHandler='../Export_Handler/FCExporter.aspx' palette='2' caption='Opened' pieSliceDepth='30' xAxisName='Month' yAxisName='Units' showValues='1' formatNumberScale='0' showBorder='0' showLegend='1' showPercemtValues='1' numberSuffix=' Email(s)' >");

        //Create recordset to get details for the factories
        SqlDataReader dr;
        String spName = "prc_getChartOneCounts";
        SqlConnection conn = new SqlConnection("Data Source=CBIL-556AC10D2D\\SQLEXPRESS;Initial Catalog=EPK_web;Persist Security Info=True;User ID=dilip;Password=cbil@360!");
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = spName;
        cmd.Connection = conn;
        cmd.Parameters.AddWithValue("@CM_ID", "1");
        
        conn.Open();
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            xmlData.AppendFormat("<set label='{0}' value='{1}' link='JavaScript:updateChart({2})' />", dr["2"].ToString(), dr["3"].ToString(), dr["1"].ToString());
        }
        conn.Close();

        //Close chart element
        xmlData.Append("</chart>");

        //Create the chart - Pie 3D Chart with data from xmlData
        return FusionCharts.RenderChart("../FusionCharts/Pie3D.swf", xmlData.ToString(), xmlData.ToString(), "myFirst", "600", "250", false, true);


    }

    public string GetFactoryDetailedChartHtml()
    {
        //Column 2D Chart with changed "No data to display" message
        //We initialize the chart with <chart></chart>
        return FusionCharts.RenderChart("../FusionCharts/Pie3D.swf?ChartNoDataText=Please select a factory from Column 3D chart above to view detailed data.", "", "<chart></chart>", "FactoryDetailed", "600", "250", false, true);
    }

    public string GetFactoryDetailDetailedChartHtml()
    {
        return FusionCharts.RenderChart("../FusionCharts/Column2D.swf?ChartNoDataText=Please select a factory from Column-2D chart above to view detailed data.", "", "<chart></chart>", "FactoryDetailDetailed", "600", "250", false, true);

    }
}
