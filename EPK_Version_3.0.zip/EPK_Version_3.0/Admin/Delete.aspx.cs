﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Delete : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["function"] != null)
        {
            if (Request.QueryString["function"] == "Delete")
                DeleteFile();
        }
    }
    public void DeleteFile()
    {
        if (Request.QueryString["FileName"] != null)
        {
            String strFileName = Request.QueryString["FileName"];
            String strPath = "";

            strPath = Server.MapPath("uploads/");
            if (System.IO.File.Exists(strPath + strFileName))
                System.IO.File.Delete(strPath + strFileName);
            String strList = Convert.ToString(Session["FileList"]);
            strList = strList.Replace(strFileName, "");
            Session["FileList"] = strList;
        }
    }
}
