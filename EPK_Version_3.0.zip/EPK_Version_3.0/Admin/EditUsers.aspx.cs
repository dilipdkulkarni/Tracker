﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer.PageMethods;

public partial class Admin_EditUsers : System.Web.UI.Page
{
    PMEditUsers objPMEditUsers = new PMEditUsers();
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(10);

        if (!IsPostBack)
        {
            if (!String.IsNullOrEmpty(Convert.ToString(Context.Items["CSUserID"])))
            {
                Int32 intID = Convert.ToInt32(Context.Items["CSUserID"]);
                String retVal = objPMEditUsers.GetUserDetails(intID);

                String[] strArr = retVal.Split('#');
                lblUser.Text = strArr[0];
                ViewState["UserID"] = strArr[1];
                ddlStatus.Items.FindByValue(strArr[2]).Selected = true;
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Int32 intID = Convert.ToInt32(ViewState["UserID"]);
        Int32 intRecState = Convert.ToInt32(ddlStatus.SelectedValue);

        objPMEditUsers.ChangeStatus(intID, intRecState);
        Response.Redirect("ViewUsers.aspx");
    }
}
