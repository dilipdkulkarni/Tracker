﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer.PageMethods;

public partial class Admin_Redirect : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((!String.IsNullOrEmpty(Request.QueryString["eid"])) && (!String.IsNullOrEmpty(Request.QueryString["id"])))
        {
            Int32 intEM_ID = Convert.ToInt32(Request.QueryString["eid"]);
            Int32 intLM_ID = Convert.ToInt32(Request.QueryString["id"]);

            //MailMe1 objMailMe = new MailMe1();
            //string strUrl = objMailMe.LinkVisited(obj);
            //if (strUrl != "")
            //{
            //    if (strLinkID == "20")
            //        Response.Redirect("http://vivapartnership.eikking.com/research1/" + strUrl + "?id=" + strGUID);
            //    else
            //        Response.Redirect("http://vivapartnership.eikking.com/research1/" + strUrl);
            //}

            PMEPKMaster objPMEPKMaster = new PMEPKMaster();
            String strUrl = objPMEPKMaster.InsertRecordLinkDtls(intEM_ID, intLM_ID);
            if (!String.IsNullOrEmpty(strUrl))
                Response.Redirect(strUrl);
        }
        else if (!String.IsNullOrEmpty(Request.QueryString["id"]))
        {
            Int32 intEM_ID = 1;
            Int32 intLM_ID = Convert.ToInt32(Request.QueryString["id"]);

            PMEPKMaster objPMEPKMaster = new PMEPKMaster();
            String strUrl = objPMEPKMaster.InsertRecordLinkDtls(intEM_ID, intLM_ID);
            if (!String.IsNullOrEmpty(strUrl))
                Response.Redirect(strUrl);
        }
    }
}
