﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using BusinessLayer.PageMethods;

public partial class Admin_ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus();
    }
    protected void btnSubmit_Click(object sender, ImageClickEventArgs e)
    {
        CommonMethods objCommonMethods = new CommonMethods();
        PMChangePassword objPMChangePassword = new PMChangePassword();

        Int32 intID = Convert.ToInt32(Session["ClientID"]);
        String strOldPwd, strNewPwd;

        strOldPwd = objCommonMethods.FilterTextBox(txtOPwd.Text);
        strNewPwd = objCommonMethods.FilterTextBox(txtPwd.Text);

        int retVal = objPMChangePassword.ChangePassword(intID, strOldPwd, strNewPwd);

        lblStatus.Text = (retVal == 0) ? "An Error has been occured." : "Password Changed Successfully.";

        clearControl();
    }

    private void clearControl()
    {
        txtOPwd.Text = "";
        txtPwd.Text = "";
        txtRePwd.Text = "";
    }

    protected void btnCancel_Click(object sender, ImageClickEventArgs e)
    {
        clearControl();
    }
}
