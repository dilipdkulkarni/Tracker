﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer.PageMethods;

public partial class Admin_Edit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(3);
        if (!IsPostBack)
        {
            grvEPK.PageIndex = 0;
            //intRow = ((grvEPK.PageIndex) * (grvEPK.PageSize));
            grvEPK.DataBind();
            if (grvEPK.Rows.Count <= 0)
            {
                pnlMain.Visible = false;
                pnlError.Visible = true;
            }
            else
            {
                PMDraft objPMDraft = new PMDraft();
                spRecs.InnerHtml = objPMDraft.GetCounts(Convert.ToInt32(Session["ClientID"]));
            }
        }
    }
    //public static Int32 intRow = 0;

    protected void grvEPK_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //Label lbl = (Label)e.Row.Cells[0].FindControl("lblSrNo");
            //intRow = intRow + 1;
            //lbl.Text = Convert.ToString((intRow == 0) ? 1 : intRow);

            LinkButton lnk = new LinkButton();
            lnk.Text = e.Row.Cells[0].Text;
            lnk.ToolTip = "Click Here to Edit";
            lnk.Style.Add("text-decoration", "none");
            lnk.CssClass = "subjectName";
            lnk.PostBackUrl = "~/Admin/Compose.aspx?id=" + e.Row.Cells[2].Text;
            e.Row.Cells[0].Controls.Add(lnk);
        }
    }

    protected void grvEPK_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        //intRow = ((grvEPK.PageIndex) * (grvEPK.PageSize));
        grvEPK.DataBind();
    }
    protected void ddlSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        grvEPK.PageIndex = 0;
        grvEPK.PageSize = Convert.ToInt32(ddlSize.SelectedValue);
        grvEPK.DataBind();
    }
}

