﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Partial Class Admin_ChartPage1
    Inherits System.Web.UI.Page

    Shared intRow As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Master.CheckUserStatus(5)

        If Not IsPostBack Then
            ddlUsers.DataBind()
            Session("ddlClientID") = IIf((String.IsNullOrEmpty(ddlUsers.SelectedValue)), Session("ClientID"), ddlUsers.SelectedValue)
            ddlEpkDt.DataBind()

            intRow = 1
            If (ddlEpkDt.Items.Count > 0) Then
                Session("SentFromDt") = ddlEpkDt.SelectedValue
                Session("SentToDt") = ddlEpkDt.SelectedValue
                BindData()
            Else
                pnlGrid.Visible = False
                pnlError.Visible = True
            End If

            ddlEpkDt.Items.Insert(0, New ListItem("All Record(s)", Convert.ToString(DBNull.Value)))
        End If
        lbl.Text = Convert.ToString(Session("lastError"))
    End Sub

    Protected Sub grvMembers_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grvMembers.PageIndexChanging
        grvMembers.PageIndex = e.NewPageIndex
        intRow = (grvMembers.PageIndex * grvMembers.PageSize) + 1
        BindData()
    End Sub

    Shared iRow As Integer
    Protected Sub grvMembers_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grvMembers.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            iRow = 1
        ElseIf e.Row.RowType = DataControlRowType.DataRow Then
            If iRow Mod 2 = 0 Then
                e.Row.Cells(3).CssClass = "subject"
                e.Row.Cells(4).CssClass = "subject"
            End If
            iRow += 1

            If (e.Row.Cells(2).Text.Length > 18) Then
                e.Row.Cells(2).ToolTip = e.Row.Cells(2).Text
                e.Row.Cells(2).Text = e.Row.Cells(2).Text.Substring(0, 18) + "..."
            End If

            If (e.Row.Cells(5).Text.Length > 18) Then
                e.Row.Cells(5).ToolTip = e.Row.Cells(5).Text
                e.Row.Cells(5).Text = e.Row.Cells(5).Text.Substring(0, 18) + "..."
            End If

            Dim lnk As HtmlAnchor = e.Row.Cells(0).FindControl("ToMail")
            lnk.HRef = "mailto:" + lnk.InnerText.Trim()

            Dim pnl As Panel
            pnl = e.Row.FindControl("pnl")
            Dim imgDtls As New Image
            imgDtls.ImageUrl = "../Images/illstration/view_list.png"
            imgDtls.Style.Add("float", "right")
            imgDtls.Style.Add("padding-right", "3px")
            If (e.Row.Cells(8).Text <> "False") Then
                pnl.Controls.Add(imgDtls)
            End If
        End If
    End Sub
    Protected Sub grvMembers_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles grvMembers.Sorting
        grvMembers.PageIndex = 0
        intRow = 1
        If (Session("SortExpression") = e.SortExpression) Then
            Session("SortDirection") = IIf((Session("SortDirection") = SortDirection.Ascending), SortDirection.Descending, SortDirection.Ascending)
        Else
            Session("SortDirection") = e.SortDirection
        End If
        Session("SortExpression") = e.SortExpression
        BindData()
    End Sub

    Protected Sub ddlSize_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSize.SelectedIndexChanged
        intRow = 1
        grvMembers.PageIndex = 0
        grvMembers.PageSize = ddlSize.SelectedValue
        BindData()
    End Sub

    Private Sub BindData()
        Session("ddlClientID") = IIf((String.IsNullOrEmpty(ddlUsers.SelectedValue)), Session("ClientID"), ddlUsers.SelectedValue)
        Session("startRowIndex") = (grvMembers.PageIndex * grvMembers.PageSize)
        Session("maximumRows") = grvMembers.PageSize
        grvMembers.DataBind()
        lblRecs.Text = "Total : " + Convert.ToString(PMChart.GetCounts()) + " Record(s)"
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        intRow = 1
        Session("SentFromDt") = txtSFrom.Text
        Session("SentToDt") = txtSTo.Text
        BindData()
    End Sub

    Protected Sub ddlEpkDt_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlEpkDt.SelectedIndexChanged
        intRow = 1

        Session("SortExpression") = ""
        Session("SortDirection") = ""
        Session("SentFromDt") = ddlEpkDt.SelectedValue
        Session("SentToDt") = ddlEpkDt.SelectedValue

        BindData()
    End Sub

    Protected Sub btnRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        intRow = 1
        Session("SortDirection") = ""
        Session("SortExpression") = ""
        BindData()
    End Sub

    Protected Sub imgNotes_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim rd As New RadioButton()
        Dim unChk As Boolean
        unChk = False
        Dim i As Integer
        For i = 0 To grvMembers.Rows.Count - 1
            rd = grvMembers.Rows(i).FindControl("rdBtn")
            If rd.Checked = True Then
                unChk = True
                Exit For
            End If
        Next

        If unChk Then
            Dim str As String
            Dim strKey As String

            Dim lnk As HtmlAnchor = grvMembers.Rows(i).Cells(0).FindControl("ToMail")
            str = lnk.InnerText.Trim()
            strKey = grvMembers.DataKeys(i).Value
            Session("ToMail") = str
            Session("strKey") = strKey
            Dim conn As New SqlConnection()

            conn = New SqlConnection(ConfigurationManager.ConnectionStrings("ev3_web").ConnectionString)

            Dim cmd As New SqlCommand("prc_sel_Notes", conn)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("key", strKey)
            cmd.Parameters.AddWithValue("ToMail", Convert.ToString(str).Trim)

            conn.Open()
            Dim strNote As String = cmd.ExecuteScalar()
            conn.Close()

            txtNote.Text = strNote

            mpeNotes.Show()
            BindData()
        End If
    End Sub

    Protected Sub imgDtls_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim rd As New RadioButton()
        Dim unChk As Boolean
        unChk = False
        Dim i As Integer
        For i = 0 To grvMembers.Rows.Count - 1
            rd = grvMembers.Rows(i).FindControl("rdBtn")
            If rd.Checked = True Then
                unChk = True
                Exit For
            End If
        Next

        If unChk Then
            Dim str As String
            Dim strKey As String
            Dim lnk As HtmlAnchor = grvMembers.Rows(i).Cells(0).FindControl("ToMail")
            str = lnk.InnerText.Trim()
            strKey = grvMembers.DataKeys(i).Value

            Session("ToMail") = str
            Session("strKey") = strKey

            grvDtls.DataBind()
            lblDtlsTotal.Text = "Total : " + Convert.ToString(PMChart.GetDtlsCount()) + " Record(s)"
            mpeDtls.Show()
            BindData()
        End If
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles btnSubmit.Click
        If txtNote.Text <> "" Then
            mpeNotes.Hide()
            Dim conn As New SqlConnection()
            conn = New SqlConnection(ConfigurationManager.ConnectionStrings("ev3_web").ConnectionString)

            Dim cmd As New SqlCommand("prc_ins_upd_Notes", conn)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("EPK_Id", Convert.ToString(Session("strKey")).Trim)
            cmd.Parameters.AddWithValue("ToMail", Convert.ToString(Session("ToMail")).Trim)
            cmd.Parameters.AddWithValue("Note", txtNote.Text)

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()

            BindData()
        End If
    End Sub

    Protected Sub imgNote_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgNote.Click
        Dim str As String
        str = Session("ToMail")

        Dim conn As New SqlConnection()

        conn = New SqlConnection(ConfigurationManager.ConnectionStrings("ev3_web").ConnectionString)

        Dim cmd As New SqlCommand("prc_sel_Notes", conn)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("key", Convert.ToString(Session("strKey")).Trim)
        cmd.Parameters.AddWithValue("ToMail", Convert.ToString(str).Trim)

        conn.Open()
        Dim strNote As String = cmd.ExecuteScalar()
        conn.Close()

        txtNote.Text = strNote
        mpeNotes.Show()
        BindData()
    End Sub

    Protected Sub btnExport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnExport.Click
        grvMembers.AllowPaging = False
        intRow = 1
        BindData()
        GridViewExportUtil.Export("Exported.xls", Me.grvMembers)
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        txtToMail.Text = ""
        txtFrom.Text = ""
        txtTo.Text = ""
        txtSFrom.Text = ""
        txtSTo.Text = ""
    End Sub

    Protected Sub ddlUsers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlUsers.SelectedIndexChanged
        Session("ddlClientID") = IIf((String.IsNullOrEmpty(ddlUsers.SelectedValue)), Session("ClientID"), ddlUsers.SelectedValue)
        ddlEpkDt.DataBind()
        ddlEpkDt.Items.Insert(0, New ListItem("All Record(s)", Convert.ToString(DBNull.Value)))
        BindData()
    End Sub
End Class
