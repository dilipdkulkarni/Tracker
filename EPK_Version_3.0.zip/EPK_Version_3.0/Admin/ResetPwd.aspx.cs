﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using BusinessLayer.PageMethods;

public partial class Admin_ResetPwd : System.Web.UI.Page
{
    CommonMethods objCommonMethods = new CommonMethods();
    PMChangePassword objPMChangePassword = new PMChangePassword();
    Crypt objCrypt = new Crypt();

    protected void Page_Load(object sender, EventArgs e)
    {
        Session["ClientID"] = "";
        if (!IsPostBack)
        {
            String strCM_ID = Request.QueryString["id"];
            Int32 intID = Convert.ToInt32(objCrypt.Decrypt(strCM_ID, true));

            int retVal = objPMChangePassword.ChkResetLink(intID);
            if (retVal == 1)
            {
                Panel1.Visible = false;
                lblStatus.Text = "You have already reset password of your account.";
            }
        }
    }

    protected void btnSubmit_Click(object sender, ImageClickEventArgs e)
    {
        String strCM_ID = Request.QueryString["id"];

        Int32 intID = Convert.ToInt32(objCrypt.Decrypt(strCM_ID, true));

        String strNewPwd;
        strNewPwd = objCommonMethods.FilterTextBox(txtPwd.Text);

        int retVal = objPMChangePassword.ResetPassword(intID, strNewPwd);

        lblStatus.Text = (retVal == 0) ? "Incorrect Username or Password entered." : "Password reset successfully. <a href='Login.aspx'>Click Here</a> to Login.";
        if (retVal != 0)
            Panel1.Visible = false;

        clearControl();
    }

    private void clearControl()
    {
        //txtUname.Text = "";
        txtPwd.Text = "";
        txtRePwd.Text = "";
    }

    protected void btnCancel_Click(object sender, ImageClickEventArgs e)
    {
        clearControl();
        lblStatus.Text = "";
    }
}
