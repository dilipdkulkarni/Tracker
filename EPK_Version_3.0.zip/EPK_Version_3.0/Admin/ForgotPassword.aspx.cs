﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer.PageMethods;
using Common;

public partial class Admin_ForgotPassword : System.Web.UI.Page
{
    CommonMethods objCommonMethods = new CommonMethods();
    PMRegister objPMRegister = new PMRegister();
    PMForgotPassword objPMForgotPassword = new PMForgotPassword();
    int retVal;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, ImageClickEventArgs e)
    {
        bool flg = false;

        if (chkName.Checked)
        {
            if (txtUName.Text == "")
            {
                lblStatus1.Text = "Enter Username.";
                return;
            }
            retVal = objPMRegister.IsUserNameExists(objCommonMethods.FilterTextBox(txtUName.Text));
            if (retVal == 0)
            {
                lblStatus1.Text = "Username is incorrect.";
                return;
            }
            else
            {
                lblSecQ.Text = objPMForgotPassword.GetSecQuestion(objCommonMethods.FilterTextBox(txtUName.Text), "");
                flg = true;
            }
        }
        else if (chkMail.Checked)
        {
            if (txtMail.Text == "")
            {
                lblStatus1.Text = "Enter Mail ID.";
                return;
            }
            retVal = objPMRegister.IsUserMailExists(objCommonMethods.FilterTextBox(txtMail.Text));
            if (retVal == 0)
            {
                lblStatus1.Text = "Mail ID is incorrect.";
                return;
            }
            else
            {
                lblSecQ.Text = objPMForgotPassword.GetSecQuestion("", objCommonMethods.FilterTextBox(txtMail.Text));
                flg = true;
            }
        }
        if (flg)
        {
            pnlFirst.Visible = false;
            pnlSecond.Visible = true;
        }
        else
        {
            lblStatus1.Text = "Enter Username or Mail ID.";
        }
    }

    protected void btnFinish_Click(object sender, ImageClickEventArgs e)
    {
        if (!String.IsNullOrEmpty(objCommonMethods.FilterTextBox(txtSecA.Text)))
        {
            String strUName, strMail, strSecAns;
            strUName = (chkName.Checked) ? objCommonMethods.FilterTextBox(txtUName.Text) : "";
            strMail = (chkMail.Checked) ? objCommonMethods.FilterTextBox(txtMail.Text) : "";
            strSecAns = objCommonMethods.FilterTextBox(txtSecA.Text);

            //String strPwd = objPMForgotPassword.GetPassword(strUName, strMail, strSecAns);
            String strRet = objPMForgotPassword.GetUserID(strUName, strMail, strSecAns);
            String[] strTmp = strRet.Split('$');
            Int32 intCM_ID = 0;

            if (strTmp.Length == 3)
                intCM_ID = Convert.ToInt32(strTmp[0]);

            if (intCM_ID > 0)
            {
                strUName = strTmp[1];
                strMail = strTmp[2];

                //lblPassword.Text = "Your Password is : <span style='color:#37C7DF;'>" + strPwd + "</span>";
                lblPassword.Text = "We have sent an email, consist of a link to reset your password. ";

                Crypt objCrypt = new Crypt();
                String strCM_ID = objCrypt.Encrypt(intCM_ID.ToString(), true);
                strCM_ID = Server.UrlEncode(strCM_ID);

                SendMail objSendMail = new SendMail();
                objSendMail.SendResetPwdLink(strCM_ID, strUName, strMail);
                pnlSecond.Visible = false;
                pnlThird.Visible = true;
            }
            else
            {
                lblStatus2.Text = "Answer is incorrect.";
            }
        }
    }
}
