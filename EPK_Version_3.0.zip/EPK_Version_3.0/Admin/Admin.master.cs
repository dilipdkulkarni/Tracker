﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Admin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
        if (String.IsNullOrEmpty(Convert.ToString(Session["ClientID"])))
            disableMenu();
    }

    public void CheckUserStatus()
    {
        if (String.IsNullOrEmpty(Convert.ToString(Session["ClientID"])))
        {
            dvMenu.Visible = false;
            Response.Redirect("Login.aspx");
        }
        else
        {
            dvMenu.Visible = true;
            lblName.Text = "Welcome " + Convert.ToString(Session["ClientName"]);
        }
    }
    public void disableMenu()
    {
        dvMenu.Visible = false;
    }
}
