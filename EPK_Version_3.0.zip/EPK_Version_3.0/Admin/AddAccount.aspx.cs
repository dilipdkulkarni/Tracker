﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using DatabaseLayout;
using BusinessLayer.PageMethods;

public partial class Admin_AddAccount : System.Web.UI.Page
{
    CommonMethods objCommonMethods = new CommonMethods();
    Dl_tbl_Card_Trn objDl_tbl_Card_Trn = new Dl_tbl_Card_Trn();
    PMAddAccount objPMAddAccount = new PMAddAccount();

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(8);

        if (!IsPostBack)
        {
        }
    }
    protected void btnFinish_Click(object sender, ImageClickEventArgs e)
    {
        lbl.Text = "";
        try
        {
            //objDl_tbl_Card_Trn.ct_Type = objCommonMethods.FilterTextBox(txtCType.Text);
            objDl_tbl_Card_Trn.ct_Type = objCommonMethods.FilterTextBox(ddlCardType.SelectedValue);
            if (CheckText(objDl_tbl_Card_Trn.ct_Type, "Enter Card Type."))
                return;

            objDl_tbl_Card_Trn.ct_No = objCommonMethods.FilterTextBox(txtCardNo.Text);
            if (CheckText(objDl_tbl_Card_Trn.ct_No, "Enter Card No."))
                return;

            objDl_tbl_Card_Trn.ct_CVV = objCommonMethods.FilterTextBox(txtCVV.Text);
            if (CheckText(objDl_tbl_Card_Trn.ct_CVV, "Enter CVV"))
                return;

            objDl_tbl_Card_Trn.ct_Name = objCommonMethods.FilterTextBox(txtCName.Text);
            if (CheckText(objDl_tbl_Card_Trn.ct_Name, "Enter Name on Card"))
                return;

            objDl_tbl_Card_Trn.CM_ID = Convert.ToInt32(Session["ClientID"]);
            objDl_tbl_Card_Trn.NoOfAccounts = Convert.ToInt32(ddlCount.SelectedValue);
            objDl_tbl_Card_Trn.ct_ExpDt = ddlMonth.SelectedValue + "/" + ddlYear.SelectedValue;

            objPMAddAccount.AddAccount(objDl_tbl_Card_Trn);

            lbl.Text = "Account(s) added successfully.";
            lbl.CssClass = "successMsg";
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message;
            lbl.CssClass = "errorMsg";
        }
    }

    private bool CheckText(String strInput, String errMsg)
    {
        if (String.IsNullOrEmpty(strInput))
            lbl.Text = errMsg;
        return (String.IsNullOrEmpty(strInput));
    }
}
