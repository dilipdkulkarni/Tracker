﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseLayout;
using System.Data.SqlClient;
using BusinessLayer.PageMethods;

public partial class Admin_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(1);
        if (!IsPostBack)
        {
            //DlUserSettings_Mst objDlUserSettings_Mst = new DlUserSettings_Mst();
            //objDlUserSettings_Mst.UM_ID = Convert.ToInt32(Session["ClientID"]);
            //SqlDataReader dr;
            //PMAfterLogin objPMAfterLogin = new PMAfterLogin();
            //dr = objPMAfterLogin.SelectRecord(objDlUserSettings_Mst);
            //if (!dr.Read())
            //{
            //    Response.Redirect("SetWizardNE.aspx");
            //}
            //else
            //{
            //    Response.Redirect("Compose.aspx");
            //}
        }
    }
}
