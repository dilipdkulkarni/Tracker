﻿using System;
using System.Web.UI;
using BusinessLayer.PageMethods;
using Common;
using DatabaseLayout;
using System.Data.SqlClient;

public partial class Admin_Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(0);

        ViewState["mgrId"] = null;
        if (!String.IsNullOrEmpty(Request.QueryString["mgrId"]))
        {
            Crypt objCrypt = new Crypt();
            ViewState["mgrId"] = objCrypt.Decrypt(Request.QueryString["mgrId"], true);
        }
    }

    protected void btnSubmit_Click(object sender, ImageClickEventArgs e)
    {
        lblChkName.Text = "";
        lblChkMail.Text = "";

        if (!String.IsNullOrEmpty(txtUName.Text.Trim()))
        {
            CommonMethods objCommonMethods = new CommonMethods();
            PMRegister objPMRegister = new PMRegister();
            String strInput;
            int retVal, retVal1, retVal2;

            strInput = objCommonMethods.FilterTextBox(txtEmail.Text);
            retVal2 = objPMRegister.IsUserMailExists(strInput);

            if (retVal2 != 0)
            {
                lblChkMail.Text = "Mail Address already exists";
                lblFP.Visible = true;
            }

            strInput = objCommonMethods.FilterTextBox(txtUName.Text);
            retVal1 = objPMRegister.IsUserNameExists(strInput);

            if (retVal1 != 0)
                lblChkName.Text = "UserName already exists";


            if ((retVal1 == 0) && (retVal2 == 0))
            {
                DlClient_Mst objDlClient_Mst = new DlClient_Mst();
                DlContact_Mst objDlContact_Mst = new DlContact_Mst();

                objDlContact_Mst.Address = getParamValue(objCommonMethods.FilterTextBox(txtAddress.Text));
                objDlContact_Mst.City = getParamValue(objCommonMethods.FilterTextBox(txtCity.Text));
                objDlContact_Mst.State = getParamValue(objCommonMethods.FilterTextBox(txtState.Text));
                objDlContact_Mst.Country = getParamValue(objCommonMethods.FilterTextBox(txtCountry.Text));
                objDlContact_Mst.Zipcode = getParamValue(objCommonMethods.FilterTextBox(txtZip.Text));
                objDlContact_Mst.Phone = getParamValue(objCommonMethods.FilterTextBox(txtPhone.Text));
                objDlContact_Mst.Mobile = getParamValue(objCommonMethods.FilterTextBox(txtMobile.Text));
                objDlContact_Mst.Email = objCommonMethods.FilterTextBox(txtEmail.Text);

                objDlClient_Mst.Name = objCommonMethods.FilterTextBox(txtName.Text);
                objDlClient_Mst.UserName = objCommonMethods.FilterTextBox(txtUName.Text);
                objDlClient_Mst.Password = objCommonMethods.FilterTextBox(txtPwd.Text);
                //objDlClient_Mst.SecQuestion = objCommonMethods.FilterTextBox(txtSecQ.Text);
                objDlClient_Mst.SecQuestion = objCommonMethods.FilterTextBox(txtSecQ.SelectedValue);
                objDlClient_Mst.SecAnswer = objCommonMethods.FilterTextBox(txtSecA.Text);
                objDlClient_Mst.ManagerID = ViewState["mgrId"];

                retVal = objPMRegister.InsertRecord(objDlContact_Mst, objDlClient_Mst);

                if (retVal >= 1)
                {
                    //lblStatus.ForeColor = System.Drawing.Color.Green;
                    //lblStatus.Text = "Record Inserted Successfully.";
                    pnlSuccess.Visible = true;
                    pnlMain.Visible = false;
                    clearControl();

                    Crypt objCrypt = new Crypt();
                    String strCode = objCrypt.Encrypt(retVal.ToString(), true);

                    strCode = Server.UrlEncode(strCode);
                    SendMail objSendMail = new SendMail();

                    if (String.IsNullOrEmpty(Convert.ToString(objDlClient_Mst.ManagerID)))
                    {
                        objSendMail.SendActivationCode(objDlClient_Mst.Name, objDlContact_Mst.Email, strCode);
                    }
                    else
                    {
                        SqlDataReader dr;
                        dr = objPMRegister.GetManagerDtls(Convert.ToInt32(objDlClient_Mst.ManagerID));

                        if (dr.Read())
                        {
                            objSendMail.SendActivationCode4Manager(objDlClient_Mst.Name, objDlContact_Mst.Email, dr["Email"].ToString(), strCode);
                            spMsg.InnerHtml = "User registered successfully. Your Manager will activate your account.";
                        }
                    }
                }
                else
                {
                    //lblStatus.ForeColor = System.Drawing.Color.Maroon;
                    //lblStatus.Text = "An Error has been occured.";
                }
            }
        }
    }

    private Object getParamValue(Object obj)
    {
        if (String.IsNullOrEmpty(Convert.ToString(obj)))
            return DBNull.Value;
        else
            return obj;
    }

    protected void btnCancel_Click(object sender, ImageClickEventArgs e)
    {
        clearControl();
    }

    private void clearControl()
    {
        txtName.Text = "";
        txtAddress.Text = "";
        txtCity.Text = "";
        txtState.Text = "";
        txtCountry.Text = "";
        txtZip.Text = "";
        txtPhone.Text = "";
        txtMobile.Text = "";
        txtEmail.Text = "";
        txtPwd.Text = "";
        txtRePwd.Text = "";
        txtUName.Text = "";
        //txtSecQ.Text = "";
        txtSecQ.SelectedIndex = -1;
        txtSecA.Text = "";
        lblChkName.Text = "";
        lblChkMail.Text = "";
        lblFP.Visible = false;
    }
}
