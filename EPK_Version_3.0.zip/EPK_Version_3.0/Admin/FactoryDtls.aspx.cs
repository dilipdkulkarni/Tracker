using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using DataConnection;
using System.Data.SqlClient;

public partial class DB_JS_dataURL_FactoryDtls : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string factoryId;
        factoryId = Request["FactoryId"];
        StringBuilder xmlData = new StringBuilder();
        //String strID = Convert.ToString(Session["ClientID"]);
        String strID = (String.IsNullOrEmpty(Convert.ToString(Session["ChartClientID"]))) ? Convert.ToString(Session["ClientID"]) : Convert.ToString(Session["ChartClientID"]);

        string query = "SELECT EPK_ID as '1', (SELECT TOP 1 Subject FROM Email_Mst Where EM_ID = EPK_ID) as '2', COUNT(ClickCnt) as '3' FROM Report_Details WHERE CM_ID = " + strID + " AND ClickCnt > 0 GROUP BY EPK_ID";

        xmlData.AppendFormat("<chart exportEnabled='1' exportAction='Download' exportAtClient='0' exportHandler='../Export_Handler/FCExporter.aspx' palette='2' caption='Subject Details' xAxisName='List of Subject(s)' showValues='1' showBorder='1' showLegend='1' showPercemtValues='1' labelDisplay='Rotate' slantLabels='1' labelStep='1' >", factoryId);
       
        SqlDataReader dr;
        //SqlConnection conn = new SqlConnection("Data Source=CBIL-556AC10D2D\\SQLEXPRESS;Initial Catalog=EPK_web;Persist Security Info=True;User ID=dilip;Password=cbil@360!");
        //SqlConnection conn = new SqlConnection("Data Source=vserver27.3essentials.com;Initial Catalog=db_epk_web;Persist Security Info=True;User ID=epkdbusr;Password=epkdb@pass");
        SqlConnection conn = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=emailTracker_web;Data Source=WORK-PC\\SQLEXPRESS");
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = query;
        cmd.Connection = conn;

        conn.Open();
        dr = cmd.ExecuteReader();

        while (dr.Read())
            xmlData.AppendFormat("<set label='{0}' value='{1}' showLabel='1'/>", dr["2"].ToString(), dr["3"].ToString(), dr["1"].ToString());
        conn.Close();
        xmlData.Append("</chart>");
        Response.ContentType = "text/xml";
        Response.Output.Write(xmlData.ToString());
    }
}
