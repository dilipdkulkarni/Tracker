﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer.PageMethods;
using Common;
using DatabaseLayout;

public partial class Admin_SetWizardNE_new : System.Web.UI.Page
{
    #region "Variable Declaration"
    CommonMethods objCommonMethods = new CommonMethods();
    DlUserSettings_Mst objDlUserSettings_Mst = new DlUserSettings_Mst();
    PMAfterLogin objPMAfterLogin = new PMAfterLogin();
    DlLink_Mst objDlLink_Mst = new DlLink_Mst();
    String strUrl = "http://localhost:1309/EPK_Version_3.0/Admin/Redirect.aspx?id=";
    Int32 iCM_ID;
    Object dbn = DBNull.Value;
    #endregion
    #region "Dictionary Variable Defination"
    private Dictionary<String, String> VImg1
    {
        get { return (Dictionary<String, String>)ViewState["img1"]; }
    }
    private Dictionary<String, String> VLnk1
    {
        get { return (Dictionary<String, String>)ViewState["lnk1"]; }
    }
    private Dictionary<String, String> VImg2
    {
        get { return (Dictionary<String, String>)ViewState["img2"]; }
    }
    private Dictionary<String, String> VLnk2
    {
        get { return (Dictionary<String, String>)ViewState["lnk2"]; }
    }
    private Dictionary<String, String> VImg3
    {
        get { return (Dictionary<String, String>)ViewState["img3"]; }
    }
    private Dictionary<String, String> VLnk3
    {
        get { return (Dictionary<String, String>)ViewState["lnk3"]; }
    }
    private Dictionary<String, String> VImg4
    {
        get { return (Dictionary<String, String>)ViewState["img4"]; }
    }
    private Dictionary<String, String> VLnk4
    {
        get { return (Dictionary<String, String>)ViewState["lnk4"]; }
    }
    #endregion

    #region "Page Method(s)"
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(6);

        litEdit1.Text += "<br />";
        litEdit2.Text += "<br />";

        //btnSave1.Attributes.Add("onclick", "fnCheck('divProgressImg1', 'ValText');");
        //btnSave2.Attributes.Add("onclick", "fnCheck('divProgressImg2', 'ValImage');");
        //btnSave3.Attributes.Add("onclick", "fnCheck('divProgressImg3', 'ValText2');");
        //btnSave4.Attributes.Add("onclick", "fnCheck('divProgressImg4', 'ValImage2');");
        //btnSave5.Attributes.Add("onclick", "fnCheck('divProgressImg5', 'ValText3');");
        //btnSave6.Attributes.Add("onclick", "fnCheck('divProgressImg6', 'ValImage3');");
        //btnSave7.Attributes.Add("onclick", "fnCheck('divProgressImg7', 'ValText4');");
        //btnSave8.Attributes.Add("onclick", "fnCheck('divProgressImg8', 'ValImage4');");

        //btn1.Attributes.Add("onclick", "fnCheck('divProgressImg1', 'ValText');");
        //btn1.Attributes.Add("onclick", "fnCheck('divProgressImg2', 'ValImage');");
        //btn2.Attributes.Add("onclick", "fnCheck('divProgressImg3', 'ValText2');");
        //btn2.Attributes.Add("onclick", "fnCheck('divProgressImg4', 'ValImage2');");
        //btn3.Attributes.Add("onclick", "fnCheck('divProgressImg5', 'ValText3');");
        //btn3.Attributes.Add("onclick", "fnCheck('divProgressImg6', 'ValImage3');");
        //btn4.Attributes.Add("onclick", "fnCheck('divProgressImg7', 'ValText4');");
        //btn4.Attributes.Add("onclick", "fnCheck('divProgressImg8', 'ValImage4');");

        ViewState["ClientID"] = Convert.ToInt32(Session["ClientID"]);

        //Response.Cache.SetCacheability(HttpCacheability.NoCache);

        if (!IsPostBack)
        {
            ViewState["USM_ID"] = "";
            getDetails();
        }
    }

    #region "User Defined Page Method(s)"
    private void setDetailsByLink(ImageButton img, LinkButton lnk, String strImgVw, String strLnkVw, int ch)
    {
        if (!String.IsNullOrEmpty(lnk.Text))
        {
            lnk.CommandArgument = (lnk.CommandName.Contains("http://")) ? lnk.CommandName.Substring(7) : lnk.CommandName;
            var vLnk = new Dictionary<String, String> { { lnk.CommandArgument, lnk.Text } };

            ViewState.Add(strLnkVw, vLnk);
            ViewState.Add(strImgVw, new Dictionary<String, String> { { "", "~/images/illstration/footerLinkImg.jpg" } });
            switch (ch)
            {
                case 1:
                    LoadLnk1();
                    break;
                case 2:
                    LoadLnk2();
                    break;
                case 3:
                    LoadLnk3();
                    break;
                case 4:
                    LoadLnk4();
                    break;
            }
        }
        else
        {
            img.CommandArgument = (img.AlternateText.Contains("http://")) ? img.AlternateText.Substring(7) : img.AlternateText;
            var vImg = new Dictionary<String, String> { { img.CommandArgument, img.ImageUrl } };

            ViewState.Add(strImgVw, vImg);
            ViewState.Add(strLnkVw, new Dictionary<String, String> { { "", "" } });
            switch (ch)
            {
                case 1:
                    LoadImg1();
                    break;
                case 2:
                    LoadImg2();
                    break;
                case 3:
                    LoadImg3();
                    break;
                case 4:
                    LoadImg4();
                    break;
            }
        }
    }
    private void getDetails()
    {
        ImageButton img = new ImageButton();
        LinkButton lnk = new LinkButton();

        //btn1.ImageUrl = "~/Images/removeDisable.gif";
        //btn2.ImageUrl = "~/Images/removeDisable.gif";
        //btn3.ImageUrl = "~/Images/removeDisable.gif";
        //btn4.ImageUrl = "~/Images/removeDisable.gif";
        btn1.Visible = false;
        btn2.Visible = false;
        btn3.Visible = false;
        btn4.Visible = false;

        objDlUserSettings_Mst.UM_ID = Convert.ToInt32(ViewState["ClientID"]);
        SqlDataReader dr;
        dr = objPMAfterLogin.SelectRecord(objDlUserSettings_Mst);
        if (dr.Read())
        {
            String iFolder = Convert.ToString(dr["ID"]);
            ViewState["USM_ID"] = iFolder;
            litEdit1.Text = dr["Signature"].ToString();
            litEdit2.Text = dr["Footer"].ToString();

            String strPath = "../EPKImg/" + iFolder + "/";
            if (!String.IsNullOrEmpty(Convert.ToString(dr["txt1"])))
            {

                lnk.Text = Convert.ToString(dr["txt1"]);
                lnk.CommandName = Convert.ToString(dr["lnk1"]);
                img.CssClass = "displayNone";
                lnk.CssClass = "";
                if (lnk.CommandName.Length > 7)
                    txtTLink.Text = lnk.CommandName.Substring(7);
                //btn1.ImageUrl = "~/Images/removeBtn.gif";
                btn1.Visible = true;
            }
            else
            {
                img.ImageUrl = "~/images/illstration/footerLinkImg.jpg";
                if (!String.IsNullOrEmpty(Convert.ToString(dr["img1"])))
                {
                    img.ImageUrl = strPath + "1" + Convert.ToString(dr["img1"]);
                    //btn1.ImageUrl = "~/Images/removeBtn.gif";
                    btn1.Visible = true;
                }
                img.AlternateText = Convert.ToString(dr["lnk1"]);
                lnk.CssClass = "displayNone";
                if (img.CommandName.Length > 7)
                    txtUrl.Text = img.AlternateText.Substring(7);
            }
            setDetailsByLink(img, lnk, "img1", "lnk1", 1);

            img = new ImageButton();
            lnk = new LinkButton();

            if (!String.IsNullOrEmpty(Convert.ToString(dr["txt2"])))
            {
                lnk.Text = Convert.ToString(dr["txt2"]);
                lnk.CommandName = Convert.ToString(dr["lnk2"]);
                lnk.CssClass = "";
                img.CssClass = "displayNone";
                if (lnk.CommandName.Length > 7)
                    txtTLink2.Text = lnk.CommandName.Substring(7);
                //btn2.ImageUrl = "~/Images/removeBtn.gif";
                btn2.Visible = true;
            }
            else
            {
                img.ImageUrl = "~/images/illstration/footerLinkImg.jpg";
                if (!String.IsNullOrEmpty(Convert.ToString(dr["img2"])))
                {
                    img.ImageUrl = strPath + "2" + Convert.ToString(dr["img2"]);
                    //btn2.ImageUrl = "~/Images/removeBtn.gif";
                    btn2.Visible = true;
                }
                img.AlternateText = Convert.ToString(dr["lnk2"]);
                lnk.CssClass = "displayNone";
                if (img.CommandName.Length > 7)
                    txtUrl2.Text = img.AlternateText.Substring(7);
            }
            setDetailsByLink(img, lnk, "img2", "lnk2", 2);

            img = new ImageButton();
            lnk = new LinkButton();

            if (!String.IsNullOrEmpty(Convert.ToString(dr["txt3"])))
            {
                lnk.Text = Convert.ToString(dr["txt3"]);
                lnk.CommandName = Convert.ToString(dr["lnk3"]);
                lnk.CssClass = "";
                img.CssClass = "displayNone";
                if (lnk.CommandName.Length > 7)
                    txtTLink3.Text = lnk.CommandName.Substring(7);
                //btn3.ImageUrl = "~/Images/removeBtn.gif";
                btn3.Visible = true;
            }
            else
            {
                img.ImageUrl = "~/images/illstration/footerLinkImg.jpg";
                if (!String.IsNullOrEmpty(Convert.ToString(dr["img3"])))
                {
                    img.ImageUrl = strPath + "3" + Convert.ToString(dr["img3"]);
                    //btn3.ImageUrl = "~/Images/removeBtn.gif";
                    btn3.Visible = true;
                }
                img.AlternateText = Convert.ToString(dr["lnk3"]);
                lnk.CssClass = "displayNone";
                if (img.CommandName.Length > 7)
                    txtUrl3.Text = img.AlternateText.Substring(7);
            }
            setDetailsByLink(img, lnk, "img3", "lnk3", 3);

            img = new ImageButton();
            lnk = new LinkButton();

            if (!String.IsNullOrEmpty(Convert.ToString(dr["txt4"])))
            {
                lnk.Text = Convert.ToString(dr["txt4"]);
                lnk.CommandName = Convert.ToString(dr["lnk4"]);
                lnk.CssClass = "";
                img.CssClass = "displayNone";
                if (lnk.CommandName.Length > 7)
                    txtTLink4.Text = lnk.CommandName.Substring(7);
                //btn4.ImageUrl = "~/Images/removeBtn.gif";
                btn4.Visible = true;
            }
            else
            {
                img.ImageUrl = "~/images/illstration/footerLinkImg.jpg";
                if (!String.IsNullOrEmpty(Convert.ToString(dr["img4"])))
                {
                    img.ImageUrl = strPath + "4" + Convert.ToString(dr["img4"]);
                    //btn4.ImageUrl = "~/Images/removeBtn.gif";
                    btn4.Visible = true;
                }
                img.AlternateText = Convert.ToString(dr["lnk4"]);
                lnk.CssClass = "displayNone";
                if (img.CommandName.Length > 7)
                    txtUrl4.Text = img.AlternateText.Substring(7);
            }
            setDetailsByLink(img, lnk, "img4", "lnk4", 4);
        }
        else
        {
            img.ImageUrl = "~/images/illstration/footerLinkImg.jpg";
            setDetailsByLink(img, lnk, "img1", "lnk1", 1);
            setDetailsByLink(img, lnk, "img2", "lnk2", 2);
            setDetailsByLink(img, lnk, "img3", "lnk3", 3);
            setDetailsByLink(img, lnk, "img4", "lnk4", 4);

        }
    }
    #endregion
    #endregion
    #region "Update Panel Load Method(s)"

    protected void updPnl1_Load(object sender, EventArgs e)
    {
        if (gvLnk1.Visible)
            LoadLnk1();
        if (gvImg1.Visible)
            LoadImg1();
    }
    protected void updPnl2_Load(object sender, EventArgs e)
    {
        if (gvLnk2.Visible)
            LoadLnk2();
        if (gvImg2.Visible)
            LoadImg2();
    }
    protected void updPnl3_Load(object sender, EventArgs e)
    {
        if (gvLnk3.Visible)
            LoadLnk3();
        if (gvImg3.Visible)
            LoadImg3();
    }
    protected void updPnl4_Load(object sender, EventArgs e)
    {
        if (gvLnk4.Visible)
            LoadLnk4();
        if (gvImg4.Visible)
            LoadImg4();
    }

    #endregion

    #region "Gridview DataBind Method(s)"
    private void LoadImg1()
    {
        gvImg1.Visible = true;
        gvLnk1.Visible = false;

        gvImg1.DataSource = ViewState["img1"];
        gvImg1.DataBind();
    }
    private void LoadLnk1()
    {
        gvImg1.Visible = false;
        gvLnk1.Visible = true;

        gvLnk1.DataSource = ViewState["lnk1"];
        gvLnk1.DataBind();
    }
    private void LoadImg2()
    {
        gvImg2.Visible = true;
        gvLnk2.Visible = false;

        gvImg2.DataSource = ViewState["img2"];
        gvImg2.DataBind();
    }
    private void LoadLnk2()
    {
        gvImg2.Visible = false;
        gvLnk2.Visible = true;

        gvLnk2.DataSource = ViewState["lnk2"];
        gvLnk2.DataBind();
    }
    private void LoadImg3()
    {
        gvImg3.Visible = true;
        gvLnk3.Visible = false;

        gvImg3.DataSource = ViewState["img3"];
        gvImg3.DataBind();
    }
    private void LoadLnk3()
    {
        gvImg3.Visible = false;
        gvLnk3.Visible = true;

        gvLnk3.DataSource = ViewState["lnk3"];
        gvLnk3.DataBind();
    }
    private void LoadImg4()
    {
        gvImg4.Visible = true;
        gvLnk4.Visible = false;

        gvImg4.DataSource = ViewState["img4"];
        gvImg4.DataBind();
    }
    private void LoadLnk4()
    {
        gvImg4.Visible = false;
        gvLnk4.Visible = true;

        gvLnk4.DataSource = ViewState["lnk4"];
        gvLnk4.DataBind();
    }
    #endregion

    #region "Save Button Click Event(s)"
    protected void btnSave1_Click(object sender, EventArgs e)
    {
        btnTextClick(1);
        SelectTab("tabs1", "tabs1-1");
        upEdit1.Update();
    }
    protected void btnSave2_Click(object sender, EventArgs e)
    {
        btnImageClick(1);
        SelectTab("tabs1", "tabs1-2");
        upEdit1.Update();
    }
    protected void btnSave3_Click(object sender, EventArgs e)
    {
        btnTextClick(2);
    }
    protected void btnSave4_Click(object sender, EventArgs e)
    {
        btnImageClick(2);
    }
    protected void btnSave5_Click(object sender, EventArgs e)
    {
        btnTextClick(3);
    }
    protected void btnSave6_Click(object sender, EventArgs e)
    {
        btnImageClick(3);
    }
    protected void btnSave7_Click(object sender, EventArgs e)
    {
        btnTextClick(4);
    }
    protected void btnSave8_Click(object sender, EventArgs e)
    {
        btnImageClick(4);
    }

    #region "User Defined Button Click Extended Method(s)"
    private void btnTextClick(int ch)
    {
        switch (ch)
        {
            case 1:
                //btn1.ImageUrl = "~/Images/removeBtn.gif";
                btn1.Visible = true;
                CloseDialog("PopUp1");

                if (VLnk1 != null) VLnk1.Clear();
                VLnk1[txtTLink.Text] = txtText.Text;
                LoadLnk1();

                UpdateImages(ch, dbn, txtText.Text, txtTLink.Text);
                updPnl1.Update();
                updEdit1.Update();
                break;
            case 2:
                //btn2.ImageUrl = "~/Images/removeBtn.gif";
                btn2.Visible = true;
                CloseDialog("PopUp2");

                if (VLnk2 != null) VLnk2.Clear();
                VLnk2[txtTLink2.Text] = txtText2.Text;
                LoadLnk2();

                UpdateImages(ch, dbn, txtText2.Text, txtTLink2.Text);
                updPnl2.Update();
                break;
            case 3:
                //btn3.ImageUrl = "~/Images/removeBtn.gif";
                btn3.Visible = true;
                CloseDialog("PopUp3");

                if (VLnk3 != null) VLnk3.Clear();
                VLnk3[txtTLink3.Text] = txtText3.Text;
                LoadLnk3();

                UpdateImages(ch, dbn, txtText3.Text, txtTLink3.Text);
                updPnl3.Update();
                break;
            case 4:
                //btn4.ImageUrl = "~/Images/removeBtn.gif";
                btn4.Visible = true;
                CloseDialog("PopUp4");

                if (VLnk4 != null) VLnk4.Clear();
                VLnk4[txtTLink4.Text] = txtText4.Text;
                LoadLnk4();

                UpdateImages(ch, dbn, txtText4.Text, txtTLink4.Text);
                updPnl4.Update();
                break;
        }
        setPanel();
    }
    private void btnImageClick(int ch)
    {
        String strTempImg = "";
        String strFileName = "";
        String txtExt = "";
        switch (ch)
        {
            case 1:
                strFileName = fu1.PostedFile.FileName;
                break;
            case 2:
                strFileName = fu2.FileName;
                break;
            case 3:
                strFileName = fu3.FileName;
                break;
            case 4:
                strFileName = fu4.FileName;
                break;
        }

        strTempImg = Server.MapPath("../EPKImg/temp/" + strFileName);
        txtExt = Path.GetExtension(strTempImg).ToLower();
        if ((txtExt == ".jpeg") || (txtExt == ".jpg") || (txtExt == ".png") || (txtExt == ".gif") || (txtExt == ".bmp"))
        {
            String strDir = Server.MapPath("../EPKImg/" + ViewState["ClientID"]);
            if (!Directory.Exists(strDir))
                Directory.CreateDirectory(strDir);

            String tmpExt = "";
            System.Drawing.Image imgNew;
            List<String> lst;

            switch (ch)
            {
                case 1:
                    fu1.PostedFile.SaveAs(strTempImg);
                    imgNew = System.Drawing.Image.FromFile(strTempImg);
                    SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/imgAdded/" + strFileName));

                    lst = new List<String>(VImg1.Keys);
                    tmpExt = Path.GetExtension(VImg1[lst[0]]);
                    if (!String.IsNullOrEmpty(tmpExt))
                        File.Delete(Server.MapPath("../EPKImg/" + ViewState["ClientID"] + "/1." + tmpExt));
                    else
                        tmpExt = Path.GetExtension(strFileName);

                    imgNew = System.Drawing.Image.FromFile(Server.MapPath("../EPKImg/imgAdded/" + strFileName));
                    SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/" + ViewState["ClientID"] + "/1" + tmpExt));

                    if (VImg1 != null) VImg1.Clear();
                    VImg1[txtUrl.Text] = "../EPKImg/" + ViewState["ClientID"] + "/1" + tmpExt + "?t=" + DateTime.Now.ToString();
                    LoadImg1();
                    CloseDialog("PopUp1");

                    UpdateImages(ch, VImg1[txtUrl.Text], dbn, txtUrl.Text);
                    txtUrl.Text = string.Empty;

                    //btn1.ImageUrl = "~/Images/removeBtn.gif";
                    btn1.Visible = true;

                    updPnl1.Update();
                    updEdit1.Update();
                    break;
                case 2:
                    fu2.SaveAs(strTempImg);
                    imgNew = System.Drawing.Image.FromFile(strTempImg);
                    SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/imgAdded/" + strFileName));

                    lst = new List<String>(VImg2.Keys);
                    tmpExt = Path.GetExtension(VImg2[lst[0]]);
                    if (!String.IsNullOrEmpty(tmpExt))
                        File.Delete(Server.MapPath("../EPKImg/" + ViewState["ClientID"] + "/2" + tmpExt));
                    else
                        tmpExt = Path.GetExtension(strFileName);

                    imgNew = System.Drawing.Image.FromFile(Server.MapPath("../EPKImg/imgAdded/" + strFileName));
                    SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/" + ViewState["ClientID"] + "/2" + tmpExt));

                    if (VImg2 != null) VImg2.Clear();
                    VImg2[txtUrl2.Text] = "../EPKImg/" + ViewState["ClientID"] + "/2" + tmpExt + "?t=" + DateTime.Now.ToString();
                    LoadImg2();
                    CloseDialog("PopUp2");

                    UpdateImages(ch, VImg2[txtUrl2.Text], dbn, txtUrl2.Text);
                    txtUrl2.Text = string.Empty;

                    //btn2.ImageUrl = "~/Images/removeBtn.gif";
                    btn2.Visible = true;

                    updPnl2.Update();
                    break;
                case 3:
                    fu3.SaveAs(strTempImg);
                    imgNew = System.Drawing.Image.FromFile(strTempImg);
                    SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/imgAdded/" + strFileName));

                    lst = new List<String>(VImg3.Keys);
                    tmpExt = Path.GetExtension(VImg3[lst[0]]);
                    if (!String.IsNullOrEmpty(tmpExt))
                        File.Delete(Server.MapPath("../EPKImg/" + ViewState["ClientID"] + "/3" + tmpExt));
                    else
                        tmpExt = Path.GetExtension(strFileName);

                    imgNew = System.Drawing.Image.FromFile(Server.MapPath("../EPKImg/imgAdded/" + strFileName));
                    SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/" + ViewState["ClientID"] + "/3" + tmpExt));

                    if (VImg3 != null) VImg3.Clear();
                    VImg3[txtUrl3.Text] = "../EPKImg/" + ViewState["ClientID"] + "/3" + tmpExt + "?t=" + DateTime.Now.ToString();
                    LoadImg3();
                    CloseDialog("PopUp3");

                    UpdateImages(ch, VImg3[txtUrl3.Text], dbn, txtUrl3.Text);
                    txtUrl3.Text = string.Empty;

                    //btn3.ImageUrl = "~/Images/removeBtn.gif";
                    btn3.Visible = true;

                    updPnl3.Update();
                    break;
                case 4:
                    fu4.SaveAs(strTempImg);
                    imgNew = System.Drawing.Image.FromFile(strTempImg);
                    SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/imgAdded/" + strFileName));

                    lst = new List<String>(VImg4.Keys);
                    tmpExt = Path.GetExtension(VImg4[lst[0]]);
                    if (!String.IsNullOrEmpty(tmpExt))
                        File.Delete(Server.MapPath("../EPKImg/" + ViewState["ClientID"] + "/4" + tmpExt));
                    else
                        tmpExt = Path.GetExtension(strFileName);

                    imgNew = System.Drawing.Image.FromFile(Server.MapPath("../EPKImg/imgAdded/" + strFileName));
                    SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/" + ViewState["ClientID"] + "/4" + tmpExt));

                    if (VImg4 != null) VImg4.Clear();
                    VImg4[txtUrl4.Text] = "../EPKImg/" + ViewState["ClientID"] + "/4" + tmpExt + "?t=" + DateTime.Now.ToString();
                    LoadImg4();
                    CloseDialog("PopUp4");

                    UpdateImages(ch, VImg4[txtUrl4.Text], dbn, txtUrl4.Text);
                    txtUrl4.Text = string.Empty;

                    //btn4.ImageUrl = "~/Images/removeBtn.gif";
                    btn4.Visible = true;

                    updPnl4.Update();
                    break;
            }
            txtId.Text = string.Empty;
        }
        else
        {
            lbl.Text = "Incorrect Image file. Please select correct Image file.";
            lbl.CssClass = "errorMsg";
        }
    }
    private void SaveImage(System.Drawing.Image image, Double dblWidth, Double dblHeight, String strPath)
    {
        String strTmpPath = Path.GetExtension(strPath); ;
        Bitmap bmp = new Bitmap((int)dblWidth, (int)dblHeight, PixelFormat.Format24bppRgb);
        bmp.SetResolution(72, 72);
        System.Drawing.Graphics gr = System.Drawing.Graphics.FromImage(bmp);
        gr.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
        gr.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
        gr.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
        System.Drawing.Rectangle rectDestination = new System.Drawing.Rectangle(0, 0, (int)dblWidth, (int)dblHeight);
        gr.DrawImage(image, rectDestination, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel);

        long quality = 90;
        EncoderParameters parameters = new EncoderParameters(1);
        parameters.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
        bmp.Save(strPath, GetCodecInfo("image/jpeg"), parameters);
        bmp.Dispose();
    }
    private static ImageCodecInfo GetCodecInfo(string mimeType)
    {
        foreach (ImageCodecInfo encoder in ImageCodecInfo.GetImageEncoders())
            if (encoder.MimeType == mimeType)
                return encoder;
        throw new ArgumentOutOfRangeException(
            string.Format("'{0}' not supported", mimeType));
    }
    #endregion

    #endregion
    #region "Finish Button Click Event(s)"

    protected void btnFinish_Click(object sender, EventArgs e)
    {
        int retVal = Finish();
        //if (retVal == 1)
        //    tblMain.Visible = false;
    }

    #region "User Defined Button Click Extended Method(s)"

    private int Finish()
    {
        String strMain, strEdit2;
        //strMain = Editor1.Text;
        strMain = hdn1.Value;
        strMain = strMain.Replace("src=\"/", "src=\"http://localhost:1309/EPK_Version_3.0/");
        strMain = strMain.Replace("src=\"../", "src=\"http://localhost:1309/EPK_Version_3.0/");
        strMain = strMain.Replace("<img ", "<img border='0' ");

        //strEdit2 = Editor2.Text;
        strEdit2 = hdn2.Value;
        strEdit2 = strEdit2.Replace("src=\"/", "src=\"http://localhost:1309/EPK_Version_3.0/");
        strEdit2 = strEdit2.Replace("<img ", "<img border='0' ");
        String strSign = InsertRecord(strMain);
        Int32 iRetVal;

        objDlLink_Mst.UM_ID = Convert.ToInt32(Session["ClientID"]);
        objDlLink_Mst.RecState = 1;

        String strFooter = getFooter(strEdit2);
        objDlUserSettings_Mst.FooterImg = strFooter;

        objDlUserSettings_Mst.UM_ID = objDlLink_Mst.UM_ID;
        objDlUserSettings_Mst.Signature = strMain;
        objDlUserSettings_Mst.FooterText = strSign;
        objDlUserSettings_Mst.Footer = strEdit2;

        if (Convert.ToString(ViewState["USM_ID"]) == "")
            iRetVal = objPMAfterLogin.InsertRecord(objDlUserSettings_Mst);
        else
        {
            objDlUserSettings_Mst.ID = Convert.ToInt32(ViewState["USM_ID"]);
            iRetVal = objPMAfterLogin.UpdateRecord(objDlUserSettings_Mst);
        }

        if (iRetVal != 0)
        {
            List<String> lstImg;

            if (Convert.ToString(ViewState["USM_ID"]) == "")
                iCM_ID = objDlLink_Mst.UM_ID;
            else
                iCM_ID = Convert.ToInt32(ViewState["USM_ID"]);
            if (!Directory.Exists(Server.MapPath("../EPKImg/" + iCM_ID)))
                Directory.CreateDirectory(Server.MapPath("../EPKImg/" + iCM_ID));
            System.Drawing.Image imgNew;
            String strTurl;

            lstImg = new List<String>(VImg1.Keys);
            strTurl = VImg1[lstImg[0]];
            if ((!String.IsNullOrEmpty(objDlUserSettings_Mst.img1)) && (strTurl.Contains("imgAdded/")))
            {
                File.Delete(Server.MapPath("../EPKImg/" + iCM_ID + "/1" + objDlUserSettings_Mst.img1));
                imgNew = System.Drawing.Image.FromFile(Server.MapPath("../imgAdded/" + strTurl));
                SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/" + iCM_ID + "/1" + objDlUserSettings_Mst.img1));
            }

            lstImg = new List<String>(VImg2.Keys);
            strTurl = VImg2[lstImg[0]];
            if ((!String.IsNullOrEmpty(objDlUserSettings_Mst.img2)) && (strTurl.Contains("imgAdded/")))
            {
                File.Delete(Server.MapPath("../EPKImg/" + iCM_ID + "/2" + objDlUserSettings_Mst.img2));
                imgNew = System.Drawing.Image.FromFile(Server.MapPath("../imgAdded/" + strTurl));
                SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/" + iCM_ID + "/2" + objDlUserSettings_Mst.img2));
            }

            lstImg = new List<String>(VImg3.Keys);
            strTurl = VImg3[lstImg[0]];
            if ((!String.IsNullOrEmpty(objDlUserSettings_Mst.img3)) && (strTurl.Contains("imgAdded/")))
            {
                File.Delete(Server.MapPath("../EPKImg/" + iCM_ID + "/3" + objDlUserSettings_Mst.img3));
                imgNew = System.Drawing.Image.FromFile(Server.MapPath("../imgAdded/" + strTurl));
                SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/" + iCM_ID + "/3" + objDlUserSettings_Mst.img3));
            }

            lstImg = new List<String>(VImg4.Keys);
            strTurl = VImg4[lstImg[0]];
            if ((!String.IsNullOrEmpty(objDlUserSettings_Mst.img4)) && (strTurl.Contains("imgAdded/")))
            {
                File.Delete(Server.MapPath("../EPKImg/" + iCM_ID + "/4" + objDlUserSettings_Mst.img4));
                imgNew = System.Drawing.Image.FromFile(Server.MapPath("../imgAdded/" + strTurl));
                SaveImage(imgNew, 117.0, 74.0, Server.MapPath("../EPKImg/" + iCM_ID + "/4" + objDlUserSettings_Mst.img4));
            }
            lbl.Text = (String.IsNullOrEmpty(Convert.ToString(ViewState["USM_ID"]))) ? "Setup Created Successfully." : "Setup Updated Successfully.";
            lbl.CssClass = "successMsg";
            getDetails();
            return 1;
        }
        else
        {
            lbl.Text = "An Error has been Occured.";
            lbl.CssClass = "errorMsg";
        }
        return 0;
    }

    private String getFooter(String strEdit2)
    {
        ImageButton img = new ImageButton();
        LinkButton lnk = new LinkButton();
        List<String> lstImg;
        List<String> lstLnk;
        String strFooter = "<table border='0' cellpadding='5' cellspacing='10' style='font-family:Arial !important; font-size:10pt !important;'><tr>";

        if (gvImg1.Visible)
        {
            lstImg = new List<String>(VImg1.Keys);
            img.CommandArgument = lstImg[0];
            img.ImageUrl = VImg1[lstImg[0]];
        }
        if (gvLnk1.Visible)
        {
            lstLnk = new List<String>(VLnk1.Keys);
            lnk.CommandArgument = lstLnk[0];
            lnk.Text = VLnk1[lstLnk[0]];
        }
        img.CssClass = (gvImg1.Visible) ? "" : "displayNone";
        lnk.CssClass = (gvLnk1.Visible) ? "" : "displayNone";

        strFooter += getLinks(img, lnk, 1);

        if (gvImg2.Visible)
        {
            lstImg = new List<String>(VImg2.Keys);
            img.CommandArgument = lstImg[0];
            img.ImageUrl = VImg2[lstImg[0]];
        }
        if (gvLnk2.Visible)
        {
            lstLnk = new List<String>(VLnk2.Keys);
            lnk.CommandArgument = lstLnk[0];
            lnk.Text = VLnk2[lstLnk[0]];
        }
        img.CssClass = (gvImg2.Visible) ? "" : "displayNone";
        lnk.CssClass = (gvLnk2.Visible) ? "" : "displayNone";

        strFooter += getLinks(img, lnk, 2);

        if (gvImg3.Visible)
        {
            lstImg = new List<String>(VImg3.Keys);
            img.CommandArgument = lstImg[0];
            img.ImageUrl = VImg3[lstImg[0]];
        }
        if (gvLnk3.Visible)
        {
            lstLnk = new List<String>(VLnk3.Keys);
            lnk.CommandArgument = lstLnk[0];
            lnk.Text = VLnk3[lstLnk[0]];
        }
        img.CssClass = (gvImg3.Visible) ? "" : "displayNone";
        lnk.CssClass = (gvLnk3.Visible) ? "" : "displayNone";

        strFooter += getLinks(img, lnk, 3);

        if (gvImg4.Visible)
        {
            lstImg = new List<String>(VImg4.Keys);
            img.CommandArgument = lstImg[0];
            img.ImageUrl = VImg4[lstImg[0]];
        }
        if (gvLnk4.Visible)
        {
            lstLnk = new List<String>(VLnk4.Keys);
            lnk.CommandArgument = lstLnk[0];
            lnk.Text = VLnk4[lstLnk[0]];
        }
        img.CssClass = (gvImg4.Visible) ? "" : "displayNone";
        lnk.CssClass = (gvLnk4.Visible) ? "" : "displayNone";

        strFooter += getLinks(img, lnk, 4);
        strFooter += "</tr></table><br />";

        if (strEdit2 != "")
            strFooter += InsertRecord(strEdit2);

        return strFooter;
    }

    private String getLinks(ImageButton img, LinkButton lnk, int ch)
    {
        String strFooter = "<td>";
        Int32 iRetVal = 0;
        if (img.CssClass != "displayNone")
        {
            if ((!img.ImageUrl.EndsWith("plus1.png")) && (!img.ImageUrl.EndsWith("footerLinkImg.jpg")))
            {
                if (img.ImageUrl.IndexOf("?") > 0)
                    img.ImageUrl = img.ImageUrl.Substring(0, img.ImageUrl.IndexOf("?"));

                if ((img.CommandArgument != "") && (!img.CommandArgument.StartsWith("http://")) && (!img.ImageUrl.EndsWith("plus1.png")))
                    img.CommandArgument = "http://" + img.CommandArgument;

                switch (ch)
                {
                    case 1:
                        objDlUserSettings_Mst.img1 = Path.GetExtension(img.ImageUrl);
                        objDlUserSettings_Mst.lnk1 = img.CommandArgument;
                        break;
                    case 2:
                        objDlUserSettings_Mst.img2 = Path.GetExtension(img.ImageUrl);
                        objDlUserSettings_Mst.lnk2 = img.CommandArgument;
                        break;
                    case 3:
                        objDlUserSettings_Mst.img3 = Path.GetExtension(img.ImageUrl);
                        objDlUserSettings_Mst.lnk3 = img.CommandArgument;
                        break;
                    case 4:
                        objDlUserSettings_Mst.img4 = Path.GetExtension(img.ImageUrl);
                        objDlUserSettings_Mst.lnk4 = img.CommandArgument;
                        break;
                }

                strFooter = "<td width='120px' style='width: 116px;height: 71px;text-align: center;vertical-align: top;overflow-x: hidden;overflow-y: auto;background-color: #DDDDDD;padding:2px;'>";
                if ((img.CommandArgument != "") && (!img.ImageUrl.EndsWith("plus1.png")))
                {
                    objDlLink_Mst.Name = img.CommandArgument;
                    objDlLink_Mst.Url = img.CommandArgument;

                    if (!String.IsNullOrEmpty(objDlLink_Mst.Url))
                    {
                        iRetVal = objPMAfterLogin.InsertRecordLink(objDlLink_Mst);
                        strFooter += "<a href='" + strUrl + iRetVal.ToString() + "'>";
                    }
                }
                String strTemp = img.ImageUrl.Replace("../EPKImg", "http://localhost:1309/EPK_Version_3.0/EPKImg");
                strFooter += "<img alt='' border='0' src='" + strTemp + "' />";

                if ((img.CommandArgument != "") && (iRetVal > 0))
                    strFooter += "</a>";
            }
        }
        else if ((lnk.CssClass != "displayNone") && (!String.IsNullOrEmpty(lnk.Text)))
        {
            if ((lnk.CommandArgument != "") && (!lnk.CommandArgument.StartsWith("http://")))
                lnk.CommandArgument = "http://" + lnk.CommandArgument;

            switch (ch)
            {
                case 1:
                    objDlUserSettings_Mst.txt1 = lnk.Text;
                    objDlUserSettings_Mst.lnk1 = lnk.CommandArgument;
                    break;
                case 2:
                    objDlUserSettings_Mst.txt2 = lnk.Text;
                    objDlUserSettings_Mst.lnk2 = lnk.CommandArgument;
                    break;
                case 3:
                    objDlUserSettings_Mst.txt3 = lnk.Text;
                    objDlUserSettings_Mst.lnk3 = lnk.CommandArgument;
                    break;
                case 4:
                    objDlUserSettings_Mst.txt4 = lnk.Text;
                    objDlUserSettings_Mst.lnk4 = lnk.CommandArgument;
                    break;
            }
            
            strFooter = "<td width='120px' style='width: 116px;height: 71px;text-align: center;vertical-align: top;overflow-x: hidden;overflow-y: auto;background-color: #DDDDDD;padding:2px;'>";
            if (lnk.CommandArgument != "")
            {
                objDlLink_Mst.Name = lnk.Text;
                objDlLink_Mst.Url = lnk.CommandArgument;

                if (!String.IsNullOrEmpty(objDlLink_Mst.Url))
                {
                    iRetVal = objPMAfterLogin.InsertRecordLink(objDlLink_Mst);
                    strFooter += "<a style='color:#007EB7 !important;' href='" + strUrl + iRetVal.ToString() + "'>";
                }
            }
            strFooter += lnk.Text;
            if ((lnk.CommandArgument != "") && (iRetVal > 0))
                strFooter += "</a>";
        }

        strFooter += "</td>";
        return strFooter;
    }
    private String InsertRecord(String strInput)
    {
        String strTmp1 = Server.HtmlDecode(strInput);
        String strTmp2 = "", strTmp3 = "";
        Int32 index = 0, iRetVal;
        String strOldUrl = "";
        String strVal;

        objDlLink_Mst.UM_ID = Convert.ToInt32(Session["ClientID"]);
        objDlLink_Mst.RecState = 1;

        while (strTmp1.LastIndexOf("href") >= 0)
        {
            index = strTmp1.LastIndexOf("href");
            strTmp3 = strTmp1.Substring(index + 6);
            strOldUrl = strTmp3.Substring(0, strTmp3.IndexOf("\""));

            objDlLink_Mst.Name = strOldUrl;
            objDlLink_Mst.Url = strOldUrl;
            iRetVal = objPMAfterLogin.InsertRecordLink(objDlLink_Mst);

            strTmp2 = "href=\"" + strUrl + (iRetVal).ToString() + strTmp3.Substring(strTmp3.IndexOf("\"")) + strTmp2;

            strTmp3 = strTmp3.Substring(0, strTmp3.IndexOf("\""));
            strTmp1 = strTmp1.Substring(0, index);
        }
        if (index == 0)
            strVal = strInput;
        else
            strVal = Server.HtmlDecode(strInput).Substring(0, index) + strTmp2;
        return strVal;

    }

    #endregion
    #endregion
    #region "Remove Button Click Event(s)"

    protected void btn1_Click(object sender, EventArgs e)
    {
        if (VImg1 != null) VImg1.Clear();
        if (VLnk1 != null) VLnk1.Clear();
        txtId.Text = "";
        txtUrl.Text = "";
        txtText.Text = "";
        txtTLink.Text = "";
        VImg1[txtUrl.Text] = "~/images/illstration/footerLinkImg.jpg";
        LoadLnk1();
        LoadImg1();
        CloseDialog("PopUp1");
        UpdateImages(1, dbn, dbn, dbn);
        updPnl1.Update();

        //btn1.ImageUrl = "~/Images/removeDisable.gif";
        btn1.Visible = false;
    }
    protected void btn2_Click(object sender, EventArgs e)
    {
        if (VImg2 != null) VImg2.Clear();
        if (VLnk2 != null) VLnk2.Clear();
        fu2.ClearAllFilesFromPersistedStore();
        txtId.Text = "";
        txtUrl2.Text = "";
        txtText2.Text = "";
        txtTLink2.Text = "";
        VImg2[txtUrl2.Text] = "~/images/illstration/footerLinkImg.jpg";
        LoadLnk2();
        LoadImg2();
        CloseDialog("PopUp2");
        UpdateImages(2, dbn, dbn, dbn);
        updPnl2.Update();

        //Remove(imgBtn2, lnkBtn2, txtUrl2, txtText2, txtTLink2);
        //btn2.ImageUrl = "~/Images/removeDisable.gif";
        btn2.Visible = false;
    }
    protected void btn3_Click(object sender, EventArgs e)
    {
        if (VImg3 != null) VImg3.Clear();
        if (VLnk3 != null) VLnk3.Clear();
        fu3.ClearAllFilesFromPersistedStore();
        txtId.Text = "";
        txtUrl3.Text = "";
        txtText3.Text = "";
        txtTLink3.Text = "";
        VImg3[txtUrl3.Text] = "~/images/illstration/footerLinkImg.jpg";
        LoadLnk3();
        LoadImg3();
        CloseDialog("PopUp3");
        UpdateImages(3, dbn, dbn, dbn);
        updPnl3.Update();

        //Remove(imgBtn3, lnkBtn3, txtUrl3, txtText3, txtTLink3);
        //btn3.ImageUrl = "~/Images/removeDisable.gif";
        btn3.Visible = false;
    }
    protected void btn4_Click(object sender, EventArgs e)
    {
        if (VImg4 != null) VImg4.Clear();
        if (VLnk4 != null) VLnk4.Clear();
        fu4.ClearAllFilesFromPersistedStore();
        txtId.Text = "";
        txtUrl4.Text = "";
        txtText4.Text = "";
        txtTLink4.Text = "";
        VImg4[txtUrl4.Text] = "~/images/illstration/footerLinkImg.jpg";
        LoadLnk4();
        LoadImg4();
        CloseDialog("PopUp4");
        UpdateImages(4, dbn, dbn, dbn);
        updPnl4.Update();

        //Remove(imgBtn4, lnkBtn4, txtUrl4, txtText4, txtTLink4);
        //btn4.ImageUrl = "~/Images/removeDisable.gif";
        btn4.Visible = false;
    }

    #region "User Defined Button Click Extended Method(s)"

    private void UpdateImages(int choice, Object img, Object txt, Object lnk)
    {
        Int32 iUM_ID = Convert.ToInt32(ViewState["ClientID"]);
        if (!String.IsNullOrEmpty(Convert.ToString(img)))
            img = Path.GetExtension(Convert.ToString(img).Substring(0, Convert.ToString(img).IndexOf("?")));
        if (!String.IsNullOrEmpty(Convert.ToString(lnk)))
            lnk = "http://" + lnk;

        String strEdit2 = hdn2.Value;
        strEdit2 = strEdit2.Replace("src=\"/", "src=\"http://localhost:1309/EPK_Version_3.0/");
        strEdit2 = strEdit2.Replace("<img ", "<img border='0' ");
        String strFooter = getFooter(strEdit2);

        ViewState["USM_ID"] = objPMAfterLogin.UpdateImages(iUM_ID, choice, img, txt, lnk, strFooter, strEdit2);
    }

    #endregion
    #endregion

    #region "JavaScript Call Method(s)"

    private void CloseDialog(string dialogId)
    {
        string script = string.Format(@"closeDialog('{0}')", dialogId);
        ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, script, true);
    }
    private void SelectTab(string dvID, string tabID)
    {
        string script = string.Format(@"fnSelectTab('{0}','{1}');", dvID, tabID);
        ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, script, true);
    }
    private void loadEditor()
    {
        string script = string.Format(@"loadEditor();");
        ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, script, true);
    }
    private void setPanel()
    {
        string script = string.Format(@"fnPnlChnage(1)");
        ScriptManager.RegisterClientScriptBlock(this, typeof(Page), UniqueID, script, true);
    }

    #endregion

    #region "Footer Link Click Method(s)"
    protected void img1_Click(object sender, ImageClickEventArgs e)
    {
        var editLink = ((ImageButton)sender);
        txtId.Text = editLink.CommandArgument;
        txtUrl.Text = editLink.CommandArgument;
        txtText.Text = "";
        txtTLink.Text = "";
        SelectTab("tabs1", "tabs1-2");
        updPnl1.Update();
    }
    protected void lnk1_Click(object sender, EventArgs e)
    {
        var editLink = ((LinkButton)sender);
        txtId.Text = editLink.CommandArgument;
        txtText.Text = editLink.Text;
        txtTLink.Text = editLink.CommandArgument;
        txtUrl.Text = "";
        SelectTab("tabs1", "tabs1-1");
        updPnl1.Update();
        upEdit1.Update();
    }
    protected void img2_Click(object sender, ImageClickEventArgs e)
    {
        var editLink = ((ImageButton)sender);
        txtId.Text = editLink.CommandArgument;
        txtUrl2.Text = editLink.CommandArgument;
        txtText2.Text = "";
        txtTLink2.Text = "";
        SelectTab("tabs2", "tabs2-2");
        updPnl2.Update();
    }
    protected void lnk2_Click(object sender, EventArgs e)
    {
        var editLink = ((LinkButton)sender);
        txtId.Text = editLink.CommandArgument;
        txtText2.Text = editLink.Text;
        txtTLink2.Text = editLink.CommandArgument;
        txtUrl2.Text = "";
        SelectTab("tabs2", "tabs2-1");
        updPnl2.Update();
    }
    protected void img3_Click(object sender, ImageClickEventArgs e)
    {
        var editLink = ((ImageButton)sender);
        txtId.Text = editLink.CommandArgument;
        txtUrl3.Text = editLink.CommandArgument;
        txtText3.Text = "";
        txtTLink3.Text = "";
        SelectTab("tabs3", "tabs3-2");
        updPnl3.Update();
    }
    protected void lnk3_Click(object sender, EventArgs e)
    {
        var editLink = ((LinkButton)sender);
        txtId.Text = editLink.CommandArgument;
        txtText3.Text = editLink.Text;
        txtTLink3.Text = editLink.CommandArgument;
        txtUrl3.Text = "";
        SelectTab("tabs3", "tabs3-1");
        updPnl3.Update();
    }
    protected void img4_Click(object sender, ImageClickEventArgs e)
    {
        var editLink = ((ImageButton)sender);
        txtId.Text = editLink.CommandArgument;
        txtUrl4.Text = editLink.CommandArgument;
        txtText4.Text = "";
        txtTLink4.Text = "";
        SelectTab("tabs4", "tabs4-2");
        updPnl4.Update();
    }
    protected void lnk4_Click(object sender, EventArgs e)
    {
        var editLink = ((LinkButton)sender);
        txtId.Text = editLink.CommandArgument;
        txtText4.Text = editLink.Text;
        txtTLink4.Text = editLink.CommandArgument;
        txtUrl4.Text = "";
        SelectTab("tabs4", "tabs4-1");
        updPnl4.Update();
    }
    #endregion
}
