﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Admin_SRAdmin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.Attributes.Add("enctype", "multipart/form-data");
    }

    public void CheckUserStatus(int ch)
    {
        if ((ch == 0) || (String.IsNullOrEmpty(Convert.ToString(Session["ClientID"]))))
        {
            lblStatus.Text = "";
            dvMenu.Visible = false;
            dvLogin.Visible = true;
            if (ch != 0)
            {
                Response.Redirect("Login.aspx");
            }
        }
        else if (!String.IsNullOrEmpty(Convert.ToString(Session["ClientID"])))
        {
            dvMenu.Visible = true;
            dvLogin.Visible = false;
            Label lbl = new Label();
            lbl.Text = "<p>Welcome " + Convert.ToString(Session["ClientName"]) + "</p><br />";
            HtmlAnchor a = new HtmlAnchor();
            a.InnerText = "Logout";
            a.Attributes.Add("class", "logout");
            a.HRef = "Login.aspx";
            lblStatus.Controls.Add(lbl);
            lblStatus.Controls.Add(a);
        }
        aHome.Attributes.Add("class","");
        aCompose.Attributes.Add("class","");
        aSent.Attributes.Add("class","");
        //aDraft.Attributes.Add("class","");
        aReport.Attributes.Add("class","");
        aChart.Attributes.Add("class","");
        aSettings.Attributes.Add("class", "");
        aLogin.Attributes.Add("class", "");
        aRegister.Attributes.Add("class", "");
        aAddAccount.Attributes.Add("class", "");
        aAddUser.Attributes.Add("class", "");
        switch (ch)
        {
            case 1:
                aHome.Attributes.Add("class", "mnuSelected");
                break;
            case 2:
                aCompose.Attributes.Add("class", "mnuSelected");
                break;
            case 3:
                aSent.Attributes.Add("class", "mnuSelected");
                break;
            case 4:
                //aDraft.Attributes.Add("class", "mnuSelected");
                break;
            case 5:
                aReport.Attributes.Add("class", "mnuSelected");
                break;
            case 6:
                aSettings.Attributes.Add("class", "mnuSelected");
                break;
            case 7:
                aChart.Attributes.Add("class", "mnuSelected");
                break;
            case 8:
                aAddAccount.Attributes.Add("class", "mnuSelected");
                break;
            case 9:
                aAddUser.Attributes.Add("class", "mnuSelected");
                break;
            case 0:
                if (Page.ToString().Contains("login"))
                    aLogin.Attributes.Add("class", "mnuSelected");
                if (Page.ToString().Contains("register"))
                    aRegister.Attributes.Add("class", "mnuSelected");
                break;
        }
    }

    public void disableMenu()
    {
        //dvMenu.Visible = false;
    }

    public void RegisterControl(Button btn)
    {
        ToolkitScriptManager1.RegisterAsyncPostBackControl(btn);
    }
}
