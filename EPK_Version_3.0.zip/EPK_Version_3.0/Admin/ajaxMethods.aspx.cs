﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer.PageMethods;

public partial class Admin_ajaxMethods : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["function"] != null)
        {
            String strFunName = Convert.ToString(Request.QueryString["function"]);
            if (strFunName == "getCounts")
            {
                String strID = Convert.ToString(Request.QueryString["id"]);
                String strEmail = Convert.ToString(Request.QueryString["mail"]);
                GetCounts(strID, strEmail);
            }
        }
    }

    private void GetCounts(String strID, String strEmail)
    {
        PMAjax objPMAjax = new PMAjax();
        String strVal = objPMAjax.GetCounts(Convert.ToInt32(strID), strEmail);
        Response.Write(strVal);
    }
}
