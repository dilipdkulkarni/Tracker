﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLayer.PageMethods;
using DatabaseLayout;
using System.Data.SqlClient;
using Common;
using System.IO;
using System.Data.Common;
using System.Net.Mail;
using System.Drawing;
using System.Text.RegularExpressions;

public partial class Admin_Compose : System.Web.UI.Page
{
    CommonMethods objCommonMethods = new CommonMethods();
    DlEPK_Details objDlEPK_Details = new DlEPK_Details();
    DlLink_Mst objDlLink_Mst = new DlLink_Mst();
    DlUserSettings_Mst objDlUserSettings_Mst = new DlUserSettings_Mst();
    PMEPKMaster objPMEPKMaster = new PMEPKMaster();
    PMAfterLogin objPMAfterLogin = new PMAfterLogin();

    String strUrl = "http://localhost:1309/EPK_Version_3.0/Admin/Redirect.aspx?id=";

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(2);
        Int32 intCM_ID = Convert.ToInt32(Session["ClientID"]);
        int iretVal = objPMEPKMaster.IsActiveUser(intCM_ID);
        if (iretVal == 1)
        {
            ibtnSend.Enabled = true;
            ibtnSend1.Enabled = true;
        }
        else
        {
            lblActive.Text = "Your email id is not authenticated. You can not send an email.";

            ibtnSend.Enabled = false;
            ibtnSend.Style.Add("opacity", "0.4");
            ibtnSend.Style.Add("filter", "alpha(opacity=40)");

            ibtnSend1.Enabled = false;
            ibtnSend1.Style.Add("opacity", "0.4");
            ibtnSend1.Style.Add("filter", "alpha(opacity=40)");
        }
        if (!IsPostBack)
        {
            Session["FileList"] = "";
            ViewState["id"] = 0;
            if (Request.QueryString["id"] != null)
            {
                ViewState["id"] = Convert.ToInt32(Request.QueryString["id"]);
                getDetails();
            }
            if (!String.IsNullOrEmpty(Convert.ToString(Session["intEM_ID"])))
            {
                lbl.Text = "Email Saved Successfully.";
                Session["intEM_ID"] = "";
            }
            PMAfterLogin objPMAfterLogin = new PMAfterLogin();
            DlUserSettings_Mst objDlUserSettings_Mst = new DlUserSettings_Mst();
            objDlUserSettings_Mst.UM_ID = intCM_ID;

            SqlDataReader dr;
            dr = objPMAfterLogin.SelectRecord(objDlUserSettings_Mst);
            if (dr.Read())
            {
                dvSign.InnerHtml = "<table border='0' cellpadding='0' cellspacing='0' width='100%'><tr><td>" + Convert.ToString(dr["Signature"]) + "</td></tr>";
                dvSign.InnerHtml += "<tr><td><br /></td></tr><tr><td>" + Convert.ToString(dr["FooterImg"]) + "</td></tr></table>";
            }
        }
    }

    private void getDetails()
    {
        Int32 epkID = Convert.ToInt32(ViewState["id"]);
        try
        {
            SqlDataReader dr;
            objDlEPK_Details.EM_ID = Convert.ToInt32(epkID);
            dr = objPMEPKMaster.SelectRecord(objDlEPK_Details);

            if (dr.Read())
            {
                txtSubject.Text = Convert.ToString(dr[1]).Trim();
                txtMsg.Text = Convert.ToString(dr[2]).Trim().Replace("  ", String.Empty);
                txtMsg.Text = Server.HtmlDecode(txtMsg.Text).Replace("&nbsp;", " ").Replace("<br />", "\n");
                txtMsg.Text = Server.HtmlDecode(Server.HtmlEncode(txtMsg.Text).Replace("&#160;", " ").Replace("  ", String.Empty));
            }
            dr.Close();
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message;
            lbl.CssClass = "errorMsg";
        }
    }

    protected void ibtnSend_Click(object sender, ImageClickEventArgs e)
    {
        Send();
    }
    protected void ibtnSend1_Click(object sender, ImageClickEventArgs e)
    {
        Send();
    }
    protected void ibtnTopSend_Click(object sender, ImageClickEventArgs e)
    {
        TestSend();
    }
    protected void ibtnTopSend1_Click(object sender, ImageClickEventArgs e)
    {
        TestSend();
    }
    protected void ibtnSave_Click(object sender, ImageClickEventArgs e)
    {
        Save(1);
    }
    protected void ibtnSave1_Click(object sender, ImageClickEventArgs e)
    {
        Save(1);
    }
    protected void ibtnCancel_Click(object sender, ImageClickEventArgs e)
    {
        Cancel();
    }
    protected void ibtnCancel1_Click(object sender, ImageClickEventArgs e)
    {
        Cancel();
    }

    private void validate()
    {

    }

    private void Send()
    {
        Object[] obj = new Object[8];

        Int32 i = 0;
        String strToName, strToMail, strBCCName, strBCCMail;
        strToName = "";
        strToMail = "";
        strBCCName = "";
        strBCCMail = "";
        obj[0] = Convert.ToString(Session["ClientName"]);
        obj[1] = Convert.ToString(Session["ClientMail"]);
        obj[4] = txtSubject.Text;
        //obj[5] = Server.HtmlDecode(txtMsg.Text.Replace(" ", "&nbsp;").Replace("\n", "<br />"));
        obj[5] = Server.HtmlDecode(hdn1.Value.Replace(" ", "&nbsp;").Replace("\n", "<br />"));

        try
        {
            if (csv.Checked)
            {
                if ((Path.GetExtension(file.FileName).Equals(".xls")) && (Path.GetExtension(file.FileName).Equals(".xlsx")))
                {
                    file.SaveAs(Server.MapPath("../EPKImg/" + file.FileName));
                    string path = Server.MapPath("../EPKImg/" + file.FileName);
                    string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";

                    Int32 delay = Convert.ToInt32(txtLimit.Text);
                    obj[7] = delay;

                    DbProviderFactory factory = DbProviderFactories.GetFactory("System.Data.OleDb");
                    using (DbConnection connection = factory.CreateConnection())
                    {
                        connection.ConnectionString = connStr;
                        using (DbCommand command = connection.CreateCommand())
                        {
                            command.CommandText = "SELECT * FROM [Sheet1$]";
                            connection.Open();
                            using (DbDataReader dr = command.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    i++;
                                    if (i == 1)
                                    {
                                        strToName = dr[1].ToString();
                                        strToMail = dr[0].ToString();
                                    }
                                    else
                                    {
                                        strBCCName += dr[1].ToString();
                                        strBCCMail += dr[0].ToString() + ",";
                                    }
                                }
                            }
                        }
                    }
                    FileInfo TheFile = new FileInfo(path);
                    if (TheFile.Exists)
                        File.Delete(path);
                }
                else if (Path.GetExtension(file.FileName).Equals(".csv"))
                {
                    Int32 delay = Convert.ToInt32(txtLimit.Text);
                    obj[7] = delay;
                    file.SaveAs(Server.MapPath("../EPKImg/" + file.FileName));
                    string path = Server.MapPath("../EPKImg/" + file.FileName);

                    StreamReader sr = new StreamReader(path);

                    string strline = "";
                    string[] _values = null;
                    bool flag = true;
                    Regex re = new Regex(@"[A-Za-z0-9_\-\.]+@([A-Za-z0-9\-]+\.)+([A-Za-z\-])+");

                    while (!sr.EndOfStream)
                    {
                        strline = sr.ReadLine();
                        _values = strline.Split(',', ';');
                        for (int t = 0; t < _values.Length; t++)
                        {
                            if (_values[t] != "")
                            {
                                i++;
                                flag = (re.IsMatch(_values[t])) ? true : false;

                                if (flag)
                                {
                                    if (i == 1)
                                        strToMail = _values[t].ToString();
                                    else
                                        strBCCMail += _values[t].ToString() + ",";
                                }
                                else
                                {
                                    if (i == 1)
                                        strToName = _values[t].ToString();
                                    else
                                        strBCCName += _values[t].ToString();
                                }
                            }
                        }
                    }
                    sr.Close();

                    FileInfo TheFile = new FileInfo(path);
                    if (TheFile.Exists)
                        File.Delete(path);
                }
                else
                {
                    lbl.Text = "Invalid File Format.";
                    lbl.CssClass = "errorMsg";
                    lbl.Visible = true;
                }
            }
            else if (manually.Checked)
            {
                i = 1;
                strToName = "";
                strToMail = txtTo.Text;
                strBCCMail = txtBcc.Text;
            }
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message;
            lbl.CssClass = "errorMsg";
            lbl.Visible = true;
        }

        if (i >= 1)
        {
            obj[2] = strToName;
            obj[3] = strToMail;
            //obj[6] = strBCCMail;

            String strName = DateTime.Now.ToString("g");
            strName = strName.Replace(" ", "_") + " " + Convert.ToString(obj[4]);
            Int32 intUM_ID = Convert.ToInt32(Session["ClientID"]);
            Int32 intEM_ID;

            objDlEPK_Details.FromName = Convert.ToString(obj[0]);
            objDlEPK_Details.FromMail = Convert.ToString(obj[1]);
            objDlEPK_Details.Subject = Convert.ToString(obj[4]);
            objDlEPK_Details.Body = Convert.ToString(obj[5]);

            intEM_ID = objPMEPKMaster.InsertRecord(strName, intUM_ID, objDlEPK_Details);

            if (!Directory.Exists(Server.MapPath("../EPKImg/" + intEM_ID)))
                Directory.CreateDirectory(Server.MapPath("../EPKImg/" + intEM_ID));

            //HttpFileCollection files = Request.Files;
            //String strLinks = "";
            //String strAttach = "";
            //Int32 iRetVal;
            //Boolean flg = false;

            //for (int k = 0; k < files.Count; k++)
            //{
            //    HttpPostedFile file = files[k];
            //    if (file.ContentLength > 0)
            //    {
            //        //fileAttach.SaveAs(Server.MapPath("../EPKImg/" + intEM_ID + "/" + file.FileName));
            //        strAttach = "http://trackr.cbil360.com/EPKImg/" + intEM_ID + "/" + file.FileName;

            //        objDlLink_Mst.Name = file.FileName;
            //        objDlLink_Mst.Url = strAttach;

            //        iRetVal = objPMAfterLogin.InsertRecordLink(objDlLink_Mst);
            //        strLinks += "<br /><br /><a href='" + strUrl + iRetVal.ToString() + "'>" + file.FileName + "</a>"; ;

            //        flg = true;
            //    }
            //}
            String strFileList = Convert.ToString(Session["FileList"]);
            String[] strList = new String[] { };
            strList = strFileList.Split('|');

            String strLinks = "";
            String strAttach = "";
            Int32 iRetVal;
            Boolean flg = false;
            String strSource, strDestination;

            for (int k = 0; k < strList.Length; k++)
            {
                if (strList[k] != "")
                {
                    strSource = Server.MapPath("uploads/" + strList[k]);
                    strDestination = Server.MapPath("../EPKImg/" + intEM_ID + "/" + strList[k]);
                    System.IO.File.Copy(strSource, strDestination, true);
                    strAttach = "http://localhost:1309/EPK_Version_3.0/EPKImg/" + intEM_ID + "/" + strList[k];
                    objDlLink_Mst.Name = strList[k];
                    objDlLink_Mst.Url = strAttach;

                    iRetVal = objPMAfterLogin.InsertRecordLink(objDlLink_Mst);
                    strLinks += "<br /><br /><a href='" + strUrl + iRetVal.ToString() + "'>" + strList[k] + "</a>"; ;

                    flg = true;
                }
            }

            if (flg)
            {
                objDlEPK_Details.EM_ID = intEM_ID;
                objDlEPK_Details.Body = Convert.ToString(obj[5]);
                objPMEPKMaster.UpdateBody(objDlEPK_Details);
            }

            string strGUID = null;
            strGUID = Convert.ToString(System.Guid.NewGuid());

            DlEmail_Mst objDlEmail_Mst = new DlEmail_Mst();
            objDlEmail_Mst.FromName = Convert.ToString(obj[0]);
            objDlEmail_Mst.FromMail = Convert.ToString(obj[1]);
            objDlEmail_Mst.ToName = Convert.ToString(obj[2]);
            objDlEmail_Mst.ToMail = Convert.ToString(obj[3]);
            objDlEmail_Mst.Subject = Convert.ToString(obj[4]);
            objDlEmail_Mst.EmailGUID = strGUID;
            objDlEmail_Mst.EM_ID = intEM_ID;
            String strInMsg = Convert.ToString(obj[5]).Trim().Replace("  ", String.Empty);
            strInMsg = Server.HtmlDecode(Server.HtmlEncode(strInMsg).Replace("&#160;", " ").Replace("  ", String.Empty));
            obj[5] = strInMsg;

            objPMEPKMaster.InsertRecordEmail(objDlEmail_Mst, strInMsg);

            SqlDataReader drTmp;
            objDlUserSettings_Mst.UM_ID = intUM_ID;
            String strMsg;
            strMsg = Convert.ToString(obj[5]);
            strMsg += strLinks;

            drTmp = objPMAfterLogin.SelectRecord(objDlUserSettings_Mst);
            if (drTmp.Read())
            {
                strMsg += "<br /><br /><table border='0' cellpadding='0' cellspacing='0' width='100%'><tr><td>" + objCommonMethods.getString(Convert.ToString(drTmp["FooterText"]));
                strMsg += "</td></tr><tr><td style='padding:10px'><br></td></tr><tr><td>" + objCommonMethods.getString(Convert.ToString(drTmp["FooterImg"])) + "</td></tr></table>";
            }
            strMsg = strMsg.Replace("Redirect.aspx?id=", "Redirect.aspx?eid=" + Convert.ToString(intEM_ID) + "&id=");
            obj[5] = strMsg;

            SendMail objSendMail = new SendMail();
            objSendMail.SendEPK(obj, strGUID);

            int iDelay = 0;
            if (txtLimit.Text != "")
                iDelay = Convert.ToInt16(txtLimit.Text);

            if (strBCCMail != "")
            {
                String[] _values = strBCCMail.Split(',');
                objDlEmail_Mst.ToName = "";
                for (int t = 0; t < _values.Length; t++)
                {
                    if (_values[t] != "")
                    {
                        strGUID = Convert.ToString(System.Guid.NewGuid());
                        obj[2] = "";
                        obj[3] = _values[t];
                        objDlEmail_Mst.FromName = Convert.ToString(obj[0]);
                        objDlEmail_Mst.FromMail = Convert.ToString(obj[1]);
                        objDlEmail_Mst.ToName = Convert.ToString(obj[2]);
                        objDlEmail_Mst.ToMail = Convert.ToString(obj[3]);
                        objDlEmail_Mst.Subject = Convert.ToString(obj[4]);
                        objDlEmail_Mst.EmailGUID = strGUID;
                        objDlEmail_Mst.EM_ID = intEM_ID;

                        objPMEPKMaster.InsertRecordEmail(objDlEmail_Mst, strInMsg);
                        objSendMail.SendEPK(obj, strGUID);
                        if (csv.Checked)
                        {
                            if (t % iDelay == 0)
                                System.Threading.Thread.Sleep(60000);
                        }
                    }
                }
            }

            clearControl();
            lbl.Text = "Mail Sent Successfully!";
            lbl.CssClass = "successMsg";
            lbl.Visible = true;
        }
    }

    private void TestSend()
    {
        Save(0);
        MailMessage mail = new MailMessage();

        mail.From = new MailAddress(Convert.ToString(Session["ClientMail"]), Convert.ToString(Session["ClientName"]));
        mail.To.Add(new MailAddress(Convert.ToString(Session["ClientMail"]), Convert.ToString(Session["ClientName"])));
        mail.Subject = txtSubject.Text;

        String str = Server.HtmlDecode(hdn1.Value.Replace(" ", "&nbsp;").Replace("\n", "<br />"));

        //HttpFileCollection files = Request.Files;
        //String strLinks = "";
        //String strAttach = "";

        //for (int k = 0; k < files.Count; k++)
        //{
        //    HttpPostedFile file = files[k];
        //    if (file.ContentLength > 0)
        //    {
        //        //fileAttach.SaveAs(Server.MapPath("../EPKImg/temp/" + file.FileName));
        //        strAttach = "http://trackr.cbil360.com/EPKImg/temp/" + file.FileName;
        //        strLinks += "<br /><br /><a href='" + strAttach + "'>" + file.FileName + "</a>"; ;
        //    }
        //}

        String strFileList = Convert.ToString(Session["FileList"]);
        String[] strList = new String[] { };
        strList = strFileList.Split('|');

        String strLinks = "";
        String strAttach = "";

        for (int k = 0; k < strList.Length; k++)
        {
            if (strList[k] != "")
            {
                strAttach = "http://localhost:1309/EPK_Version_3.0/EPKImg/temp/" + strList[k];
                strLinks += "<br /><br /><a href='" + strAttach + "'>" + strList[k] + "</a>"; ;
            }
        }

        str += strLinks;
        str += "<br /><br />" + dvSign.InnerHtml;
        str = Convert.ToString(str).Trim().Replace("  ", String.Empty);
        str = Server.HtmlDecode(Server.HtmlEncode(str).Replace("&#160;", " ").Replace("  ", String.Empty));

        AlternateView htmlView = AlternateView.CreateAlternateViewFromString(str, null, "text/html");
        mail.AlternateViews.Add(htmlView);

        SendMail objSendMail = new SendMail();
        objSendMail.SendTestEPK(mail);

        lbl.Text = "Test Mail Sent Successfully to " + Convert.ToString(Session["ClientMail"]);
        lbl.CssClass = "successMsg";
    }

    private void Save(int ch)
    {
        Object[] obj = new Object[8];
        try
        {
            Int32 epkID = Convert.ToInt32(ViewState["id"]);

            obj[0] = Convert.ToString(Session["ClientName"]);
            obj[1] = Convert.ToString(Session["ClientMail"]);
            obj[4] = txtSubject.Text;
            //obj[5] = Server.HtmlDecode(txtMsg.Text.Replace(" ", "&nbsp;").Replace("\n", "<br />"));
            obj[5] = Server.HtmlDecode(hdn1.Value.Replace(" ", "&nbsp;").Replace("\n", "<br />"));

            String strName = DateTime.Now.ToString("g");
            strName = strName.Replace(" ", "_") + " " + Convert.ToString(obj[4]);
            Int32 intUM_ID = Convert.ToInt32(Session["ClientID"]);
            DlEPK_Details objDlEPK_Details = new DlEPK_Details();

            objDlEPK_Details.FromName = Convert.ToString(obj[0]);
            objDlEPK_Details.FromMail = Convert.ToString(obj[1]);
            objDlEPK_Details.Subject = Convert.ToString(obj[4]);
            objDlEPK_Details.Body = Convert.ToString(obj[5]);

            Int32 intEM_ID;

            if (epkID > 0)
            {
                objDlEPK_Details.EM_ID = epkID;
                objPMEPKMaster.UpdateRecord(strName, intUM_ID, objDlEPK_Details);
                intEM_ID = epkID;
            }
            else
                intEM_ID = objPMEPKMaster.InsertRecord(strName, intUM_ID, objDlEPK_Details);

            if (intEM_ID > 0)
            {
                //HttpFileCollection files = Request.Files;
                //String strLinks = "";
                //String strAttach = "";
                //Int32 iRetVal;
                //Boolean flg = false;

                //for (int k = 0; k < files.Count; k++)
                //{
                //    HttpPostedFile file = files[k];
                //    if (file.ContentLength > 0)
                //    {
                //        if ((!Directory.Exists(Server.MapPath("../EPKImg/" + intEM_ID))) && !flg)
                //            Directory.CreateDirectory(Server.MapPath("../EPKImg/" + intEM_ID));

                //        //fileAttach.SaveAs(Server.MapPath("../EPKImg/" + intEM_ID + "/" + file.FileName));
                //        strAttach = "http://trackr.cbil360.com/EPKImg/" + intEM_ID + "/" + file.FileName;

                //        objDlLink_Mst.Name = file.FileName;
                //        objDlLink_Mst.Url = strAttach;

                //        iRetVal = objPMAfterLogin.InsertRecordLink(objDlLink_Mst);
                //        strLinks = "<br /><br /><a href='" + strUrl + iRetVal.ToString() + "'>" + file.FileName + "</a>"; ;

                //        obj[5] += strLinks;
                //        flg = true;
                //    }
                //}
                String strFileList = Convert.ToString(Session["FileList"]);
                String[] strList = new String[] { };
                strList = strFileList.Split('|');
                String strSource, strDestination;

                String strLinks = "";
                String strAttach = "";
                Int32 iRetVal;
                Boolean flg = false;

                for (int k = 0; k < strList.Length; k++)
                {
                    if (strList[k] != "")
                    {
                        strSource = Server.MapPath("uploads/" + strList[k]);
                        strDestination = Server.MapPath("../EPKImg/" + intEM_ID + "/" + strList[k]);
                        System.IO.File.Copy(strSource, strDestination);

                        if ((!Directory.Exists(Server.MapPath("../EPKImg/" + intEM_ID))) && !flg)
                            Directory.CreateDirectory(Server.MapPath("../EPKImg/" + intEM_ID));

                        strAttach = "http://localhost:1309/EPK_Version_3.0/EPKImg/" + intEM_ID + "/" + strList[k];

                        objDlLink_Mst.Name = strList[k];
                        objDlLink_Mst.Url = strAttach;

                        iRetVal = objPMAfterLogin.InsertRecordLink(objDlLink_Mst);
                        strLinks = "<br /><br /><a href='" + strUrl + iRetVal.ToString() + "'>" + strList[k] + "</a>"; ;

                        obj[5] += strLinks;
                        flg = true;
                    }
                }

                if (flg)
                {
                    objDlEPK_Details.EM_ID = intEM_ID;
                    objDlEPK_Details.Body = Convert.ToString(obj[5]);
                    objPMEPKMaster.UpdateBody(objDlEPK_Details);
                }
                if (ch != 0)
                {
                    lbl.Text = "Email Saved Successfully.";
                    lbl.CssClass = "successMsg";
                    //clearControl();
                    Session["intEM_ID"] = intEM_ID;
                    Response.Redirect("Default.aspx");
                }
            }
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message;
            lbl.Visible = true;
        }
    }

    private void Cancel()
    {
    }

    private void clearControl()
    {
        txtTo.Text = "";
        txtBcc.Text = "";
        txtSubject.Text = "";
        txtMsg.Text = "";
        txtLimit.Text = "";
        lbl.Text = "";
    }
}
