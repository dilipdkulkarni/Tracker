﻿using System;
using System.Web.UI;
using BusinessLayer.PageMethods;
using Common;
using DatabaseLayout;

public partial class Admin_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            Session["ClientID"] = null;
            Session["ClientName"] = null;
            Session.Clear();
        }

        if (!String.IsNullOrEmpty(Convert.ToString(Context.Items["Active"])))
        {
            if (Convert.ToString(Context.Items["Active"]) == "0")
            {
                FailureText.CssClass = "errorMsg";
                FailureText.Text = "You are already Activated.";
            }
            else
            {
                FailureText.CssClass = "successMsg";
                FailureText.Text = "You are Activated Successfully. Welcome to Email Tracker.";
            }
        }
        
        Master.CheckUserStatus(0);
    }
    protected void LoginButton_Click(object sender, ImageClickEventArgs e)
    {
        if (!String.IsNullOrEmpty(UserName.Text.Trim()))
        {
            CommonMethods objCommonMethods = new CommonMethods();
            PMLogin objPMLogin = new PMLogin();
            String retVal = "";

            DlClient_Mst objDlClient_Mst = new DlClient_Mst();
            objDlClient_Mst.UserName = objCommonMethods.FilterTextBox(UserName.Text);
            objDlClient_Mst.Password = objCommonMethods.FilterTextBox(Password.Text);
            retVal = objPMLogin.ClientLogin(objDlClient_Mst);

            if ((!String.IsNullOrEmpty(retVal)))
            {
                String[] arr = retVal.Split('$');
                if (arr.Length < 4)
                {
                    FailureText.CssClass = "errorMsg";
                    FailureText.Text = arr[1];
                    return;
                }

                Session["ClientID"] = arr[0];
                Session["ClientName"] = arr[1];
                Session["UserTypeId"] = arr[2];
                Session["ClientMail"] = arr[3];
                Response.Redirect("Home.aspx");
            }
            else
            {
                FailureText.Text = "Incorrect username or password. Please try again.";
            }
        }

    }
}
