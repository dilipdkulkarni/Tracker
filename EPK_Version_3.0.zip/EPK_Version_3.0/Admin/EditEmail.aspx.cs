﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_EditEmail : System.Web.UI.Page
{
    public void Page_Load(object sender, EventArgs E)
    {
        if (!IsPostBack)
        {
            Master.CheckUserStatus(8);
            LoadXML();
        }
    }

    public void LoadXML()
    {
        DataSet objdata = new DataSet();

        try
        {
            objdata.ReadXml(Server.MapPath("sample.xml"));
            //datagrid1.Datasource = objdata;
            //datagrid1.Databind();
        }
        catch
        {
            CreateXML();
        }
    }


    public void CreateXML()
    {
        DataSet objdata = new DataSet("root");
        DataTable dt = new DataTable("record");
        DataRow dr = null;

        dt.Columns.Add(new DataColumn("aid"));
        dt.Columns.Add(new DataColumn("name"));
        dt.Columns.Add(new DataColumn("dept"));
        dt.Columns.Add(new DataColumn("salary"));

        dr = dt.NewRow();
        dr[0] = "1";
        dr[1] = "No Data";
        dr[2] = "No Data";
        dr[3] = "No Data";

        dt.Rows.Add(dr);

        objdata.Tables.Add(dt);

        //datagrid1.datasource = objdata;
        //datagrid1.databind();

        objdata.WriteXml(Server.MapPath("sample.xml"));

        LoadXML();
    }


    public void setEditMode(object Sender, DataGridCommandEventArgs E)
    {

        DataSet objdata = new DataSet();
        string x1 = null;

        objdata.ReadXml(Server.MapPath("sample.xml"));

        //x1 = datagrid1.DataKeys.Item(E.Item.ItemIndex);

        objdata.Tables["record"].DefaultView.RowFilter = "aid='" + x1 + "'";

        if (objdata.Tables["record"].DefaultView.Count > 0)
        {
            //error4.visible = "False";
            //datagrid1.EditItemIndex = E.Item.ItemIndex;
            //datagrid1.showfooter = "false";
            LoadXML();
        }
        else
        {
            //error4.visible = "True";
        }
    }


    public void cancelEdit(object sender, DataGridCommandEventArgs E)
    {
        //datagrid1.EditItemIndex = -1;
        //datagrid1.showfooter = "true";
        //error1.visible = "False";
        //error2.visible = "False";
        //error3.visible = "False";
        //error4.visible = "False";
        //error5.visible = "False";

        LoadXML();

    }


    public void DelXML(object S, DataGridCommandEventArgs E)
    {
        if (E.CommandName == "Delete")
        {
            //if (datagrid1.EditItemIndex == -1)
            {
                //error5.visible = "False";
                string x1 = null;

                //x1 = datagrid1.DataKeys.Item(E.Item.ItemIndex);

                DataSet objdata = new DataSet();
                try
                {
                    objdata.ReadXml(Server.MapPath("sample.xml"));
                    objdata.Tables["record"].DefaultView.RowFilter = "aid='" + x1 + "'";
                    if (objdata.Tables["record"].DefaultView.Count > 0)
                    {
                        objdata.Tables["record"].DefaultView.Delete(0);
                    }

                    objdata.Tables["record"].DefaultView.RowFilter = "";

                    objdata.WriteXml(Server.MapPath("sample.xml"));
                }
                catch
                {
                    CreateXML();
                }

                LoadXML();
            }
            //else
            //{
            //    error5.visible = "True";
            //}
        }
    }


    public void UpdateXML(object s, DataGridCommandEventArgs e)
    {
        if (e.CommandName == "Update")
        {
            string str1 = null;
            string str2 = null;
            string str3 = null;
            string v1 = null;
            //Textbox txt1 = default(Textbox);
            //Textbox txt2 = default(Textbox);
            //Textbox txt3 = default(Textbox);
            DataSet objdata = new DataSet();
            string x1 = null;

            objdata.ReadXml(Server.MapPath("sample.xml"));

            //v1 = e.Item.ItemIndex;

            //x1 = datagrid1.DataKeys.Item(e.Item.ItemIndex);

            objdata.Tables["record"].DefaultView.RowFilter = "aid='" + x1 + "'";

            if (objdata.Tables["record"].DefaultView.Count > 0)
            {
                //error3.visible = "False";

                //txt1 = e.Item.FindControl("name_edit");
                //txt2 = e.Item.FindControl("dept_edit");
                //txt3 = e.Item.FindControl("sal_edit");

                //objdata.Tables["record"].Rows[v1]["name"] = txt1.Text;
                //objdata.Tables["record"].Rows[v1]["dept"] = txt2.Text;
                //objdata.Tables["record"].Rows[v1]["salary"] = txt3.Text;
                //datagrid1.datasource = objdata;
                //datagrid1.databind();

                objdata.WriteXml(Server.MapPath("sample.xml"));

                //datagrid1.EditItemIndex = -1;
                LoadXML();
                //datagrid1.showfooter = "true";
            }
            else
            {
                //error3.visible = "True";
            }
        }
    }



    public void doInsert(object s, DataGridCommandEventArgs E)
    {
        //if (E.CommandName == "doAdd")
        //{
        //    string v1 = null;
        //    Textbox tadd1 = default(Textbox);
        //    Textbox tadd2 = default(Textbox);
        //    Textbox tadd3 = default(Textbox);
        //    Textbox tadd4 = default(Textbox);
        //    DataSet objdata = new DataSet();
        //    DataRow dr = null;

        //    objdata.ReadXml(Server.Mappath("sample.xml"));

        //    tadd1 = E.Item.FindControl("aid_add");
        //    tadd2 = E.Item.FindControl("name_add");
        //    tadd3 = E.Item.FindControl("dept_add");
        //    tadd4 = E.Item.FindControl("sal_add");

        //    try
        //    {
        //        tadd1.text = Int32.Parse(tadd1.text);
        //        error2.visible = "false";

        //        if (tadd1.text < 1)
        //        {
        //            tadd1.Text = "";
        //            error2.visible = "true";
        //        }
        //    }
        //    catch
        //    {
        //        tadd1.text = "";
        //        error2.visible = "true";
        //    }

        //    if (!string.IsNullOrEmpty(tadd1.Text) & !string.IsNullOrEmpty(tadd2.Text) & !string.IsNullOrEmpty(tadd3.Text) & !string.IsNullOrEmpty(tadd4.Text))
        //    {
        //        objdata.Tables["record"].DefaultView.RowFilter = "aid='" + tadd1.Text + "'";
        //        if (objdata.Tables["record"].DefaultView.Count <= 0)
        //        {
        //            error1.visible = "False";
        //            objdata.Tables["record"].DefaultView.RowFilter = "";
        //            dr = objdata.Tables["record"].NewRow();

        //            dr[0] = tadd1.Text;
        //            dr[1] = tadd2.Text;
        //            dr[2] = tadd3.Text;
        //            dr[3] = tadd4.Text;
        //            objdata.Tables["record"].Rows.Add(dr);

        //            objdata.WriteXml(Server.mappath("sample.xml"));
        //            LoadXML();
        //        }
        //        else
        //        {
        //            error1.visible = "True";
        //            error1.Text = "Id must be unique";
        //        }
        //    }
        //}
    }


    private int lastVarValue;
    public object showval(int a)
    {
        lastVarValue = a;
        return a;
    }


}
