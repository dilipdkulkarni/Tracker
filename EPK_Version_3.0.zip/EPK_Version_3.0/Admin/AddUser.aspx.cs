﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using BusinessLayer.PageMethods;
using DatabaseLayout;

public partial class Admin_AddUser : System.Web.UI.Page
{

    CommonMethods objCommonMethods = new CommonMethods();
    DlRequest_Dtls objDlRequest_Dtls = new DlRequest_Dtls();
    PMAddUser objPMAddUser = new PMAddUser();
    SendMail objSendMail = new SendMail();

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(9);
    }

    protected void btnFinish_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            PMRegister objPMRegister = new PMRegister();
            int  retVal;

            objDlRequest_Dtls.Name = objCommonMethods.FilterTextBox(txtName.Text);
            objDlRequest_Dtls.Email = objCommonMethods.FilterTextBox(txtEmail.Text);
            if (CheckText(objDlRequest_Dtls.Name, "Enter Name."))
                return;

            if (CheckText(objDlRequest_Dtls.Email, "Enter Email ID."))
                return;

            retVal = objPMRegister.IsUserMailExists(objDlRequest_Dtls.Email);

            if (retVal != 0)
            {
                lbl.Text = "Mail Address already exists";
                lbl.CssClass = "errorMsg";
                return;
            }

            objDlRequest_Dtls.CM_ID = Convert.ToInt32(Session["ClientID"]);
            
            String strVal = objPMAddUser.IsRequestEmailExists(objDlRequest_Dtls);
            if (strVal == "1")
            {
                lbl.Text = "Request already sent to this email id.";
                lbl.CssClass = "errorMsg";
                return;
            }

            Int32 iRetVal = objPMAddUser.AddUser(objDlRequest_Dtls);
            if (iRetVal > 0)
            {
                Crypt objCrypt = new Crypt();
                String strCode = objCrypt.Encrypt(iRetVal.ToString(), true);

                strCode = Server.UrlEncode(strCode);
                objSendMail.SendRegistrationRequest(objDlRequest_Dtls.Name, objDlRequest_Dtls.Email, strCode);
                lbl.Text = "Request sent successfully.";
                lbl.CssClass = "successMsg";
            }
            else
            {
                lbl.Text = "An error has been occured.";
                lbl.CssClass = "errorMsg";
            }
        }
        catch (Exception ex)
        {
            lbl.Text = ex.Message;
            lbl.CssClass = "errorMsg";
        }
    }
    private bool CheckText(String strInput, String errMsg)
    {
        if (String.IsNullOrEmpty(strInput))
            lbl.Text = errMsg;
        return (String.IsNullOrEmpty(strInput));
    }
}
