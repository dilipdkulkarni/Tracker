﻿using System;
using BusinessLayer.PageMethods;
using Common;

public partial class Admin_ActivateAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(0);

        if (!IsPostBack)
        {
            if (Request.QueryString.Count == 2)
            {
                if ((!String.IsNullOrEmpty(Request.QueryString["email"])) && (!String.IsNullOrEmpty(Request.QueryString["actCode"])))
                {
                    String strMail, strCode;
                    strMail = Request.QueryString["email"];
                    strCode = Request.QueryString["actCode"];

                    Crypt objCrypt = new Crypt();
                    Int32 intClientID = Convert.ToInt32(objCrypt.Decrypt(strCode, true));

                    PMActivate objPMActivate = new PMActivate();
                    Int32 iVal = objPMActivate.ActivateClient(intClientID);

                    if (iVal > 0)
                    {

                        SendMail objSendMail = new SendMail();
                        objSendMail.SendActivationConfirm(strMail);
                        pnlSuccess.Visible = true;
                        //lblStatus.Text = "You are Activated Successfully.";
                    }
                    else
                    {
                        pnlError.Visible = true;
                    }
                    Context.Items.Add("Active", iVal);
                    Server.Transfer("Login.aspx");
                }
            }
        }
    }
}
