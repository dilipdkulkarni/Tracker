﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using InfoSoftGlobal;
using DataConnection;
using BusinessLayer.PageMethods;
using System.Data.SqlClient;

public partial class Admin_Chart : System.Web.UI.Page
{
    PMChart objPMChart = new PMChart();
    Int32 intCM_ID;

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.CheckUserStatus(7);
        if (!IsPostBack)
            ddlUsers.DataBind();
        Literal1.Text = GetFactorySummaryChartHtml();
        Literal2.Text = GetFactoryDetailedChartHtml();
        Literal3.Text = GetFactoryDetailDetailedChartHtml();
        lbl.Text = Convert.ToString(Session["lastError"]);
    }

    public string GetFactorySummaryChartHtml()
    {
        Session["ChartClientID"] = ddlUsers.SelectedValue;
        intCM_ID = Convert.ToInt32(Session["ChartClientID"]);
        //Int32 intCM_ID = Convert.ToInt32(Session["ClientID"]);
        StringBuilder xmlData = new StringBuilder();

        //xmlData.Append("<chart exportEnabled='1' exportAction='Download' exportAtClient='0' exportHandler='../Export_Handler/FCExporter.aspx' caption='Opened' pieSliceDepth='30' xAxisName='Month' yAxisName='Units' showValues='0' formatNumberScale='0' showBorder='1' numberSuffix=' Units' >");
        xmlData.Append("<chart exportEnabled='1' exportAction='Download' exportAtClient='0' exportHandler='../Export_Handler/FCExporter.aspx' palette='2' caption='Opened' pieSliceDepth='30' xAxisName='Month' yAxisName='Units' showValues='1' formatNumberScale='0' showBorder='1' showLegend='1' showPercemtValues='1' numberSuffix=' Email(s)' >");

        SqlDataReader dr;
        dr = objPMChart.ChartOne(intCM_ID);

        while (dr.Read())
        {
            xmlData.AppendFormat("<set label='{0}' value='{1}' link='JavaScript:updateChart({2})' />", dr["2"].ToString(), dr["3"].ToString(), dr["1"].ToString());
        }

        xmlData.Append("</chart>");

        return FusionCharts.RenderChart("../FusionCharts/Pie3D.swf", xmlData.ToString(), xmlData.ToString(), "myFirst", "800", "250", false, true);
    }

    public string GetFactoryDetailedChartHtml()
    {
        //Column 2D Chart with changed "No data to display" message
        //We initialize the chart with <chart></chart>
        return FusionCharts.RenderChart("../FusionCharts/Pie3D.swf?ChartNoDataText=Please select a factory from Column 3D chart above to view detailed data.", "", "<chart></chart>", "FactoryDetailed", "800", "250", false, true);
    }

    public string GetFactoryDetailDetailedChartHtml()
    {
        return FusionCharts.RenderChart("../FusionCharts/Column2D.swf?ChartNoDataText=Please select a factory from Column-2D chart above to view detailed data.", "", "<chart></chart>", "FactoryDetailDetailed", "800", "400", false, true);
    }
    protected void ddlUsers_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["ChartClientID"] = ddlUsers.SelectedValue;
        intCM_ID = Convert.ToInt32(Session["ChartClientID"]);
        GetFactorySummaryChartHtml();
    }
}
