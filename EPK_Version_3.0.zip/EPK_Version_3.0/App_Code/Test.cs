﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using BusinessLayer.PageMethods;
using DatabaseLayout;
using Common;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Test
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class Test : System.Web.Services.WebService
{

    public Test()
    {
        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }

    [WebMethod]
    public long factorial(long number)
    {
        long dbl = 1;
        if (number > 0)
        {
            int i = 0;
            for (i = 1; i <= number; i++)
            {
                dbl = dbl * i;
            }
        }
        return dbl;
    }

    [WebMethod]
    public string fnSendEmail(String strInput)
    {
        try
        {
            String[] strArr;
            String[] strArr1 = new String[] { "###" };
            strArr = strInput.Split(strArr1, StringSplitOptions.None);
            String fromEmail, toEmail, subject, fileName;
            fromEmail = strArr[0];
            toEmail = strArr[1];
            subject = strArr[2];
            fileName = strArr[3];

            CommonMethods objCommonMethods = new CommonMethods();
            SendMail objSendMail = new SendMail();
            PMCBIL_EPK objPMCBIL_EPK = new PMCBIL_EPK();
            PMEPKMaster objPMEPKMaster = new PMEPKMaster();
            PMAfterLogin objPMAfterLogin = new PMAfterLogin();
            DlEPK_Details objDlEPK_Details = new DlEPK_Details();
            DlEmail_Mst objDlEmail_Mst = new DlEmail_Mst();
            DlLink_Mst objDlLink_Mst = new DlLink_Mst();
            DlUserSettings_Mst objDlUserSettings_Mst = new DlUserSettings_Mst();
            String strUrl = "http://localhost:1309/EPK_Version_3.0/Admin/Redirect.aspx?id=";
            String strMsg = "";
            String strGUID1 = null;
            String strGUID2 = null;
            SqlDataReader drTmp;
            Object[] obj = new Object[4];

            String strName = DateTime.Now.ToString("g");
            strName = strName.Replace(" ", "_") + " " + subject;
            Int32 intUM_ID = 7; //Convert.ToInt32(Session["ClientID"]);
            objDlEPK_Details.FromName = Convert.ToString(fromEmail);
            objDlEPK_Details.FromMail = Convert.ToString(fromEmail);
            objDlEPK_Details.Subject = Convert.ToString(subject);
            objDlEPK_Details.Body = "";

            Int32 intEM_ID = objPMCBIL_EPK.InsertRecord(strName, intUM_ID, objDlEPK_Details);

            String strAttach = "http://www.cbil360.com/uploads/" + fileName;
            objDlLink_Mst.Name = fileName;
            objDlLink_Mst.Url = strAttach;

            Int32 iRetVal = objPMAfterLogin.InsertRecordLink(objDlLink_Mst);
            strMsg += "<br /><br /><a href='" + strUrl + iRetVal.ToString() + "'>" + fileName + "</a>";

            strGUID1 = Convert.ToString(System.Guid.NewGuid());

            objDlEmail_Mst.FromName = Convert.ToString(fromEmail);
            objDlEmail_Mst.FromMail = Convert.ToString(fromEmail);
            objDlEmail_Mst.ToName = Convert.ToString(toEmail);
            objDlEmail_Mst.ToMail = Convert.ToString(toEmail);
            objDlEmail_Mst.Subject = Convert.ToString(subject);
            objDlEmail_Mst.EmailGUID = strGUID1;
            objDlEmail_Mst.EM_ID = intEM_ID;

            objPMEPKMaster.InsertRecordEmail(objDlEmail_Mst, strMsg);

            strGUID2 = Convert.ToString(System.Guid.NewGuid());

            objDlEmail_Mst.FromName = Convert.ToString("cbil360@cbil360.com");
            objDlEmail_Mst.FromMail = Convert.ToString("cbil360@cbil360.com");
            objDlEmail_Mst.ToName = Convert.ToString(fromEmail);
            objDlEmail_Mst.ToMail = Convert.ToString(fromEmail);
            objDlEmail_Mst.Subject = ""; //Convert.ToString(subject);
            objDlEmail_Mst.EmailGUID = strGUID2;
            objDlEmail_Mst.EM_ID = intEM_ID;

            objPMEPKMaster.InsertRecordEmail(objDlEmail_Mst, strMsg);

            objDlUserSettings_Mst.UM_ID = intUM_ID;

            drTmp = objPMAfterLogin.SelectRecord(objDlUserSettings_Mst);
            if (drTmp.Read())
            {
                strMsg += "<br /><br /><table border='0' cellpadding='0' cellspacing='0' width='100%'><tr><td>" + objCommonMethods.getString(Convert.ToString(drTmp["FooterText"]));
                strMsg += "</td></tr><tr><td style='padding:10px'><br></td></tr><tr><td>" + objCommonMethods.getString(Convert.ToString(drTmp["FooterImg"])) + "</td></tr></table>";
            }
            strMsg = strMsg.Replace("Redirect.aspx?id=", "Redirect.aspx?eid=" + Convert.ToString(intEM_ID) + "&id=");

            obj[0] = fromEmail;
            obj[1] = toEmail;
            obj[2] = subject;
            obj[3] = strMsg;
            objSendMail.SendCBIL_EPK(obj, strGUID1);

            obj[0] = "cbil360@cbil360.com";
            obj[1] = fromEmail;
            obj[2] = ""; //subject;
            obj[3] = strMsg;
            objSendMail.SendCBIL_EPK(obj, strGUID2);
        }
        catch (Exception)
        {
            return "error";
        }
        return "success";
    }
}

