﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Services;

/// <summary>
/// Summary description for AutoComplete
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class AutoComplete : System.Web.Services.WebService {

    [WebMethod()]
    [System.Web.Script.Services.ScriptMethod()]
    public string[] GetFromMail(string prefixText, string count, string contextKey)
    {
        DataSet dtst = new DataSet();
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["promoter_webConnectionString"].ConnectionString);
        string strSql = "Select Distinct FromMail From tb_EmailInfo Where strKey = '" + contextKey + "' AND FromMail LIKE '" + prefixText + "%' ";
        SqlCommand sqlComd = new SqlCommand(strSql, sqlCon);
        sqlCon.Open();
        SqlDataAdapter sqlAdpt = new SqlDataAdapter();
        sqlAdpt.SelectCommand = sqlComd;
        sqlAdpt.Fill(dtst);
        string[] cntName = new string[dtst.Tables[0].Rows.Count];
        int i = 0;
        try
        {
            foreach (DataRow rdr in dtst.Tables[0].Rows)
            {
                cntName.SetValue(rdr["FromMail"].ToString(), i);
                i += 1;
            }
        }
        catch
        {
        }
        finally
        {
            sqlCon.Close();
        }
        return cntName;
    }

    [WebMethod()]
    [System.Web.Script.Services.ScriptMethod()]
    public string[] GetToMail(string prefixText, string count, string contextKey)
    {
        DataSet dtst = new DataSet();
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["promoter_webConnectionString"].ConnectionString);

        string[] strParam = null;
        strParam = contextKey.Split(',');

        string strSql = "Select Distinct ToMail From tb_EmailInfo Where strKey = '" + strParam[0].Trim() + "' AND ToMail LIKE '" + prefixText + "%' ";
        if (!string.IsNullOrEmpty(strParam[1]))
        {
            strSql = " AND FromMail = '" + strParam[1].Trim() + "' ";
        }

        SqlCommand sqlComd = new SqlCommand(strSql, sqlCon);
        sqlCon.Open();
        SqlDataAdapter sqlAdpt = new SqlDataAdapter();
        sqlAdpt.SelectCommand = sqlComd;
        sqlAdpt.Fill(dtst);
        string[] cntName = new string[dtst.Tables[0].Rows.Count];
        int i = 0;
        try
        {
            foreach (DataRow rdr in dtst.Tables[0].Rows)
            {
                cntName.SetValue(rdr["ToMail"].ToString(), i);
                i += 1;
            }
        }
        catch
        {
        }
        finally
        {
            sqlCon.Close();
        }
        return cntName;
    }
    
}

