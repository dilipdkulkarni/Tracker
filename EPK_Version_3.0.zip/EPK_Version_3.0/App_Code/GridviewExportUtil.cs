﻿using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public class GridViewExportUtil
{
    public static void Export(string fileName, GridView gv)
    {
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", fileName));
        HttpContext.Current.Response.ContentType = "application/ms-excel";
        StringWriter sw = new StringWriter();
        HtmlTextWriter htw = new HtmlTextWriter(sw);
        //  Create a form to contain the grid
        Table table = new Table();
        table.GridLines = gv.GridLines;
        //  add the header row to the table
        if ((((gv.HeaderRow) != null)))
        {
            GridViewExportUtil.PrepareControlForExport(gv.HeaderRow);
            table.Rows.Add(gv.HeaderRow);
        }
        //  add each of the data rows to the table
        foreach (GridViewRow row in gv.Rows)
        {
            GridViewExportUtil.PrepareControlForExport(row);
            table.Rows.Add(row);
        }
        //  add the footer row to the table
        if ((((gv.FooterRow) != null)))
        {
            GridViewExportUtil.PrepareControlForExport(gv.FooterRow);
            table.Rows.Add(gv.FooterRow);
        }
        //  render the table into the htmlwriter
        table.RenderControl(htw);
        //  render the htmlwriter into the response
        HttpContext.Current.Response.Write(sw.ToString());
        HttpContext.Current.Response.End();
    }

    // Replace any of the contained controls with literals
    private static void PrepareControlForExport(Control control)
    {
        int i = 0;
        int cnt = 0;
        cnt = ((control is GridView) ? control.Controls.Count - 1 : control.Controls.Count);
        while ((i < cnt))
        {
            Control current = control.Controls[i];
            if ((current is LinkButton))
            {
                control.Controls.Remove(current);
                if ((((LinkButton)current).Text != "strNote"))
                {
                    control.Controls.AddAt(i, new LiteralControl(((LinkButton)current).Text));
                }
            }
            else if ((current is RadioButton))
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl(""));
            }
            else if ((current is ImageButton))
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl(""));
            }
            else if ((current is HyperLink))
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl(((HyperLink)current).Text));
            }
            else if ((current is DropDownList))
            {
                control.Controls.Remove(current);
                control.Controls.AddAt(i, new LiteralControl(((DropDownList)current).SelectedItem.Text));
            }
            //else if ((current is CheckBox))
            //{
            //    control.Controls.Remove(current);
            //    control.Controls.AddAt(i, new LiteralControl(((CheckBox)current).Checked));
            //    //TODO: Warning!!!, inline IF is not supported ?
            //}
            if (current.HasControls())
            {
                GridViewExportUtil.PrepareControlForExport(current);
            }
            i = (i + 1);
        }
    }
}
