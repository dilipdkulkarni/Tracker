﻿using System;
using Common;
using DatabaseLayout;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMAddAccount
        {
            int returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public int AddAccount(Dl_tbl_Card_Trn objDl_tbl_Card_Trn)
            {
                spName = "prc_AddAccount";
                parameterValues = new object[] { objDl_tbl_Card_Trn.CM_ID, objDl_tbl_Card_Trn.NoOfAccounts, objDl_tbl_Card_Trn.ct_Type,
                                                    objDl_tbl_Card_Trn.ct_Holder, objDl_tbl_Card_Trn.ct_No, objDl_tbl_Card_Trn.ct_Name,
                                                    objDl_tbl_Card_Trn.ct_CVV, objDl_tbl_Card_Trn.ct_ExpDt };
                returnValue = dlObject.ExecuteNonQuery(parameterValues, spName);
                return returnValue;
            }
        }
    }
}