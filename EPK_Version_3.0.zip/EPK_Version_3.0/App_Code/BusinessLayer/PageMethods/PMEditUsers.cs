﻿
using Common;
using DatabaseLayout;
using System;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMEditUsers
        {
            String returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public String GetUserDetails(Int32 ID)
            {
                spName = "prc_getUserDetails";
                parameterValues = new object[] { ID };
                returnValue = dlObject.ExecuteScalarString(parameterValues, spName);
                return returnValue;
            }

            public Int32 ChangeStatus(Int32 ID, Int32 RecState)
            {
                spName = "prc_ChangeUserStatus";
                parameterValues = new object[] { ID, RecState };
                Int32 retVal = dlObject.ExecuteNonQuery(parameterValues, spName);
                return retVal;
            }

        }
    }
}