﻿using Common;
using DatabaseLayout;
using System;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMForgotPassword
        {
            String returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public String GetSecQuestion(String strUserName, String strEmail)
            {
                spName = "prc_GetSecQuestion";
                parameterValues = new object[] { strUserName, strEmail};
                returnValue = dlObject.ExecuteScalarString(parameterValues, spName);
                return returnValue;
            }

            public String GetPassword(String strUserName, String strEmail, String strSecAns)
            {
                spName = "prc_GetPassword";
                parameterValues = new object[] { strUserName, strEmail, strSecAns };
                returnValue = dlObject.ExecuteScalarString(parameterValues, spName);
                return returnValue;
            }

            public String GetUserID(String strUserName, String strEmail, String strSecAns)
            {
                spName = "prc_GetUserID";
                parameterValues = new object[] { strUserName, strEmail, strSecAns };
                returnValue = dlObject.ExecuteScalarString(parameterValues, spName);
                return returnValue;
            }
        }
    }
}