﻿using Common;
using DatabaseLayout;
using System;
using System.Data.SqlClient;
using System.Data;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMChart
        {
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public SqlDataReader ChartOne(Int32 intCM_ID)
            {
                SqlDataReader dr;
                spName = "prc_getChartOneCounts";
                parameterValues = new object[] { intCM_ID };
                dr = dlObject.ExecuteReader(parameterValues, spName);
                return dr;
            }

            public SqlDataReader ChartTwo(Int32 intCM_ID)
            {
                SqlDataReader dr;
                spName = "prc_getChartTwoCounts";
                parameterValues = new object[] { intCM_ID };
                dr = dlObject.ExecuteReader(parameterValues, spName);
                return dr;
            }

            public static DataSet ds;
            public static DataSet dsDtls;

            public static DataView GetValues(String strCM_ID, String strEPK_Id, String strToMail, String strSentFromDt, String strSentToDt, String strFromDt, String strToDt, String strSortExpression, String strSortDirection, Int32 startRowIndex, Int32 maximumRows)
            {
                String prcName = "prc_DisplayReport";
                //Object[] param = new object[] { strCM_ID, strEPK_Id, strToMail, strSentFromDt, strSentToDt, strFromDt, strToDt, strSortExpression, strSortDirection, startRowIndex, maximumRows };
                Object[] param = new object[] { strCM_ID, strEPK_Id, strToMail, strSentFromDt, strSentToDt, strFromDt, strToDt, strSortExpression, strSortDirection };
                DataMethods dlData = new DataMethods();
                ds = dlData.ExecuteDataset(prcName, param);
                return ds.Tables[0].DefaultView;
            }
            public static Int32 GetCounts()
            {
                if (ds.Tables.Count > 0)
                    return Convert.ToInt32(ds.Tables[0].Rows.Count);
                else
                    return 0;
            }

            public static DataView GetDetails(String strCM_ID, String strEPK_Id, String strToMail)
            {
                String prcName = "prc_MailDetails";
                Object[] param = new object[] { strCM_ID, strEPK_Id, strToMail };
                DataMethods dlData = new DataMethods();
                dsDtls = dlData.ExecuteDataset(prcName, param);
                return dsDtls.Tables[0].DefaultView;
            }
            public static Int32 GetDtlsCount()
            {
                if (dsDtls.Tables.Count > 0)
                    return Convert.ToInt32(dsDtls.Tables[0].Rows.Count);
                else
                    return 0;
            }
        }
    }
}