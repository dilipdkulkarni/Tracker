﻿using System;
using Common;
using DatabaseLayout;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMAddUser
        {
            int returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public Int32 AddUser(DlRequest_Dtls objDlRequest_Dtls)
            {
                spName = "prc_ins_Request_Dtls";
                parameterValues = new object[] { objDlRequest_Dtls.ID, objDlRequest_Dtls.CM_ID, objDlRequest_Dtls.Name, objDlRequest_Dtls.Email };
                returnValue = dlObject.ExecuteNonQuery(parameterValues, spName);
                return returnValue;
            }

            public String IsRequestEmailExists(DlRequest_Dtls objDlRequest_Dtls)
            {
                String retVal = "";
                spName = "prc_IsRequestEmailExists";
                parameterValues = new object[] { objDlRequest_Dtls.CM_ID, objDlRequest_Dtls.Email };
                retVal = dlObject.ExecuteScalarString(parameterValues, spName);
                return retVal;
            }
        }
    }
}