﻿using System;
using Common;
using DatabaseLayout;
using System.Data.SqlClient;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMAfterLogin
        {
            int retVal;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public int InsertRecord(DlUserSettings_Mst objDlUserSettings_Mst)
            {
                spName = "prc_ins_UserSettings_Mst";
                parameterValues = new Object[] { objDlUserSettings_Mst.ID, objDlUserSettings_Mst.UM_ID, 
                                                objDlUserSettings_Mst.Signature, objDlUserSettings_Mst.FooterImg, objDlUserSettings_Mst.FooterText,
                                                objDlUserSettings_Mst.Footer, 
                                                objDlUserSettings_Mst.img1, objDlUserSettings_Mst.img2, objDlUserSettings_Mst.img3,
                                                objDlUserSettings_Mst.img4, objDlUserSettings_Mst.txt1, objDlUserSettings_Mst.txt2,
                                                objDlUserSettings_Mst.txt3, objDlUserSettings_Mst.txt4, objDlUserSettings_Mst.lnk1,
                                                objDlUserSettings_Mst.lnk2, objDlUserSettings_Mst.lnk3, objDlUserSettings_Mst.lnk4

                };
                retVal = dlObject.ExecuteNonQuery(parameterValues, spName);
                return retVal;
            }

            public int UpdateRecord(DlUserSettings_Mst objDlUserSettings_Mst)
            {
                spName = "prc_upd_UserSettings_Mst";
                parameterValues = new Object[] { objDlUserSettings_Mst.ID, objDlUserSettings_Mst.UM_ID, 
                                                objDlUserSettings_Mst.Signature,objDlUserSettings_Mst.FooterImg, objDlUserSettings_Mst.FooterText,
                                                objDlUserSettings_Mst.Footer, 
                                                objDlUserSettings_Mst.img1, objDlUserSettings_Mst.img2, objDlUserSettings_Mst.img3,
                                                objDlUserSettings_Mst.img4, objDlUserSettings_Mst.txt1, objDlUserSettings_Mst.txt2,
                                                objDlUserSettings_Mst.txt3, objDlUserSettings_Mst.txt4, objDlUserSettings_Mst.lnk1,
                                                objDlUserSettings_Mst.lnk2, objDlUserSettings_Mst.lnk3, objDlUserSettings_Mst.lnk4};
                retVal = dlObject.ExecuteNonQuery(parameterValues, spName);
                return retVal;
            }

            public int UpdateImages(Int32 UM_ID, int choice, Object img, Object txt, Object lnk, String strFooterImg, String strFooter)
            {
                spName = "prc_upd_Images";
                if (img == DBNull.Value && txt == DBNull.Value)
                    parameterValues = new Object[] { UM_ID, choice, strFooterImg, null, null, null, strFooter };
                else
                    parameterValues = new Object[] { UM_ID, choice, strFooterImg, img, txt, lnk, strFooter };
                retVal = dlObject.ExecuteNonQuery(parameterValues, spName);
                return retVal;
            }

            public SqlDataReader SelectRecord(DlUserSettings_Mst objDlUserSettings_Mst)
            {
                SqlDataReader dr;
                spName = "prc_sel_UserSettings_Mst";
                parameterValues = new object[] { objDlUserSettings_Mst.UM_ID };
                dr = dlObject.ExecuteReader(parameterValues, spName);
                return dr;
            }

            public int InsertRecordLink(DlLink_Mst objDlLink_Mst)
            {
                spName = "prc_ins_Link_Mst_User";
                parameterValues = new Object[] { objDlLink_Mst.ID, objDlLink_Mst.Name, objDlLink_Mst.Url, null, objDlLink_Mst.RecState, objDlLink_Mst.UM_ID };
                retVal = dlObject.ExecuteNonQuery(parameterValues, spName);
                return retVal;
            }
        }
    }
}