﻿using Common;
using DatabaseLayout;
using System;
using System.Data.SqlClient;
using System.Data;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMDraft
        {
            String returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public String GetCounts(Int32 intCM_ID)
            {
                spName = "prc_CountDraft";
                parameterValues = new Object[] { intCM_ID };
                returnValue = dlObject.ExecuteScalarString(parameterValues, spName);
                return returnValue;
            }

        }
    }
} 