﻿using System;
using Common;
using DatabaseLayout;
using System.Data.SqlClient;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMRegister
        {
            Int32 retVal;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public int IsUserNameExists(String strUserName)
            {
                spName = "prc_IsUserNameExists";
                parameterValues = new Object[] { strUserName };
                retVal = dlObject.ExecuteScalar(parameterValues, spName);
                return retVal;
            }

            public int IsUserMailExists(String strEmail)
            {
                spName = "prc_IsUserMailExists";
                parameterValues = new Object[] { strEmail };
                retVal = dlObject.ExecuteScalar(parameterValues, spName);
                return retVal;
            }

            public int InsertRecord(DlContact_Mst objDlContact_Mst, DlClient_Mst objDlClient_Mst)
            {
                spName = "prc_CreateClient";
                parameterValues = new Object[] {objDlClient_Mst.ID, objDlClient_Mst.Name, objDlClient_Mst.UserName, objDlClient_Mst.Password,
                                                objDlContact_Mst.Email, objDlClient_Mst.SecQuestion, objDlClient_Mst.SecAnswer,
                                                objDlContact_Mst.Address, objDlContact_Mst.City, objDlContact_Mst.State, objDlContact_Mst.Country,
                                                objDlContact_Mst.Zipcode, objDlContact_Mst.Phone, objDlContact_Mst.Mobile, objDlClient_Mst.ManagerID};
                retVal = dlObject.ExecuteScalar(parameterValues, spName);
                return retVal;
            }

            public SqlDataReader GetManagerDtls(Int32 intID)
            {
                SqlDataReader dr;
                spName = "prc_GetManagerDtls";
                parameterValues = new object[] { intID };
                dr = dlObject.ExecuteReader(parameterValues, spName);
                return dr;
            }
        }
    }
}