﻿using System;
using Common;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMActivate
        {
            int returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public int ActivateClient(Int32 intClientID)
            {
                spName = "prc_ActivateClient";
                parameterValues = new object[] { intClientID };
                returnValue = dlObject.ExecuteNonQuery(parameterValues, spName);
                return returnValue;
            }
        }
    }
}