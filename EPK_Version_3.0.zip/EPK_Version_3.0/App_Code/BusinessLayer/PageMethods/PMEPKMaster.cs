﻿using System;
using Common;
using DatabaseLayout;
using System.Data.SqlClient;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMEPKMaster
        {
            int retVal;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;


            public int InsertRecordEPK(DlEPK_Mst objDlEPK_Mst)
            {
                spName = "prc_ins_EPK_Mst";
                parameterValues = new Object[] { objDlEPK_Mst.ID, objDlEPK_Mst.Name, objDlEPK_Mst.CM_ID };
                retVal = dlObject.ExecuteNonQuery(parameterValues, spName);
                return retVal;
            }

            public int InsertRecord(String strEPKName, Int32 intCM_ID, DlEPK_Details objDlEPK_Details)
            {
                spName = "prc_ins_EPK_Details";
                parameterValues = new Object[] {strEPKName, intCM_ID, objDlEPK_Details.FromName, objDlEPK_Details.FromMail,
                                                objDlEPK_Details.Subject, objDlEPK_Details.Body};
                retVal = Convert.ToInt32(dlObject.ExecuteScalar(parameterValues, spName));
                return retVal;
            }

            public int InsertRecordEmail(DlEmail_Mst objDlEmail_Mst, String strMsg)
            {
                spName = "prc_ins_Email_Mst";
                parameterValues = new Object[] {objDlEmail_Mst.ID, objDlEmail_Mst.FromName, objDlEmail_Mst.FromMail, objDlEmail_Mst.ToName, 
                                                objDlEmail_Mst.ToMail, objDlEmail_Mst.Subject, strMsg, objDlEmail_Mst.EmailGUID, objDlEmail_Mst.EM_ID };
                retVal = dlObject.ExecuteScalar(parameterValues, spName);
                return retVal;
            }

            public int UpdateRecord(String strEPKName, Int32 intCM_ID, DlEPK_Details objDlEPK_Details)
            {
                spName = "prc_upd_EPK_Details";
                parameterValues = new Object[] {strEPKName, intCM_ID, objDlEPK_Details.EM_ID, objDlEPK_Details.FromName, 
                                                objDlEPK_Details.FromMail, objDlEPK_Details.Subject, objDlEPK_Details.Body};
                retVal = dlObject.ExecuteScalar(parameterValues, spName);
                return retVal;
            }

            public SqlDataReader SelectRecord(DlEPK_Details objDlEPK_Details)
            {
                SqlDataReader dr;
                spName = "prc_sel_EPK_Details";
                parameterValues = new object[] { objDlEPK_Details.EM_ID };
                dr = dlObject.ExecuteReader(parameterValues, spName);
                return dr;
            }

            public SqlDataReader SelectRecord(Int32 intEM_ID, Int32 intUM_ID)
            {
                SqlDataReader dr;
                spName = "prc_sel_EPK_Details";
                parameterValues = new object[] { intEM_ID, intUM_ID };
                dr = dlObject.ExecuteReader(parameterValues, spName);
                return dr;
            }

            public int InsertRecordLink(DlLink_Mst objDlLink_Mst)
            {
                spName = "prc_ins_Link_Mst";
                if (objDlLink_Mst.EM_ID == 0)
                    parameterValues = new Object[] { objDlLink_Mst.ID, objDlLink_Mst.Name, objDlLink_Mst.Url, null, objDlLink_Mst.RecState };
                else
                    parameterValues = new Object[] { objDlLink_Mst.ID, objDlLink_Mst.Name, objDlLink_Mst.Url, objDlLink_Mst.EM_ID, objDlLink_Mst.RecState };
                retVal = dlObject.ExecuteNonQuery(parameterValues, spName);
                return retVal;
            }

            public String InsertRecordLinkDtls(Int32 intEM_ID, Int32 intLM_ID)
            {
                spName = "prc_ins_Link_Dtls";
                parameterValues = new Object[] { intEM_ID, intLM_ID };
                String strVal = dlObject.ExecuteScalarString(parameterValues, spName);
                return strVal;
            }

            public int IsEmailConfigured(String strEmail)
            {
                spName = "prc_IsEmailConfigured";
                parameterValues = new Object[] { strEmail };
                retVal = Convert.ToInt16(dlObject.ExecuteScalar(parameterValues, spName));
                return retVal;
            }

            public int IsActiveUser(Int32 intUid)
            {
                spName = "prc_IsActiveUser";
                parameterValues = new Object[] { intUid };
                retVal = Convert.ToInt16(dlObject.ExecuteScalar(parameterValues, spName));
                return retVal;
            }

            public int UpdateBody(DlEPK_Details objDlEPK_Details)
            {
                spName = "prc_upd_EPK_Details_Body";
                parameterValues = new Object[] { objDlEPK_Details.EM_ID, objDlEPK_Details.Body };
                retVal = dlObject.ExecuteNonQuery(parameterValues, spName);
                return retVal;
            }
        }
    }
}