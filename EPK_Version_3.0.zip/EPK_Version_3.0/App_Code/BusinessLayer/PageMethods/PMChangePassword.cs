﻿using Common;
using DatabaseLayout;
using System;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMChangePassword
        {
            int returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public int ChangePassword(Int32 intID, String strUserName, String strEmail)
            {
                spName = "prc_ChangePassword";
                parameterValues = new object[] { intID, strUserName, strEmail };
                returnValue = dlObject.ExecuteScalar(parameterValues, spName);
                return returnValue;
            }

            public int ResetPassword(Int32 intID, String strPwd)
            {
                spName = "prc_ResetPassword";
                parameterValues = new object[] { intID, strPwd };
                returnValue = dlObject.ExecuteScalar(parameterValues, spName);
                return returnValue;
            }

            public int ChkResetLink(Int32 intID)
            {
                spName = "prc_ChkResetLink";
                parameterValues = new object[] { intID };
                returnValue = dlObject.ExecuteScalar(parameterValues, spName);
                return returnValue;
            }
        }
    }
}