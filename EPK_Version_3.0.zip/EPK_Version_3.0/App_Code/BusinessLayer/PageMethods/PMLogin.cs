﻿using Common;
using DatabaseLayout;
using System;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMLogin
        {
            String returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public String ClientLogin(DlClient_Mst tableObject)
            {
                spName = "prc_ClientLogin";
                parameterValues = new object[] { tableObject.UserName, tableObject.Password };
                returnValue = dlObject.ExecuteScalarString(parameterValues, spName);
                return returnValue;
            }

            public String ClientLogin(DlUser_Mst tableObject)
            {
                spName = "prc_UserLogin";
                parameterValues = new object[] { tableObject.UserName, tableObject.Password };
                returnValue = dlObject.ExecuteScalarString(parameterValues, spName);
                return returnValue;
            }
        }
    }
}