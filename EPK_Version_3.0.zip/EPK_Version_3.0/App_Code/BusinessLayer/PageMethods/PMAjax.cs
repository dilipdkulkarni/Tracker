﻿using Common;
using DatabaseLayout;
using System;

namespace BusinessLayer
{
    namespace PageMethods
    {
        public class PMAjax
        {
            String returnValue;
            DataMethods dlObject = new DataMethods();
            String spName = null;
            Object[] parameterValues = null;

            public String GetCounts(Int32 intEPK_ID, String strEmail)
            {
                spName = "prc_GetCounts";
                parameterValues = new object[] { intEPK_ID, strEmail };
                returnValue = dlObject.ExecuteScalarString(parameterValues, spName);
                return returnValue;
            }
        }
    }
}