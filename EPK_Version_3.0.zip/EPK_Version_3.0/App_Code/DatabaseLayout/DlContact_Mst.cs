﻿using System;

namespace DatabaseLayout
{
    public class DlContact_Mst
    {
        private Int32 _ID;
        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private Object _Address = DBNull.Value;
        public Object Address
        {
            get { return _Address; }
            set { _Address = value; }
        }

        private Object _City = DBNull.Value;
        public Object City
        {
            get { return _City; }
            set { _City = value; }
        }

        private Object _State = DBNull.Value;
        public Object State
        {
            get { return _State; }
            set { _State = value; }
        }

        private Object _Country = DBNull.Value;
        public Object Country
        {
            get { return _Country; }
            set { _Country = value; }
        }

        private Object _Zipcode = DBNull.Value;
        public Object Zipcode
        {
            get { return _Zipcode; }
            set { _Zipcode = value; }
        }

        private Object _Phone = DBNull.Value;
        public Object Phone
        {
            get { return _Phone; }
            set { _Phone = value; }
        }

        private Object _Mobile = DBNull.Value;
        public Object Mobile
        {
            get { return _Mobile; }
            set { _Mobile = value; }
        }

        private String _Email;
        public String Email
        {
            get { return _Email; }
            set { _Email = value; }
        }

        private Object _Facebook = DBNull.Value;
        public Object Facebook
        {
            get { return _Facebook; }
            set { _Facebook = value; }
        }

        private Object _Twitter = DBNull.Value;
        public Object Twitter
        {
            get { return _Twitter; }
            set { _Twitter = value; }
        }

        private Object _Orkut = DBNull.Value;
        public Object Orkut
        {
            get { return _Orkut; }
            set { _Orkut = value; }
        }
    }
}