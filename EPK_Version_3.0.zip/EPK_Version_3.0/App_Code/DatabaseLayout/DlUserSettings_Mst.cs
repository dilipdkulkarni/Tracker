﻿using System;

namespace DatabaseLayout
{
    public class DlUserSettings_Mst
    {
        private Int32 _ID;
        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private Int32 _UM_ID;
        public Int32 UM_ID
        {
            get { return _UM_ID; }
            set { _UM_ID = value; }
        }

        private String _Signature;
        public String Signature
        {
            get { return _Signature; }
            set { _Signature = value; }
        }

        private String _FooterImg;
        public String FooterImg
        {
            get { return _FooterImg; }
            set { _FooterImg = value; }
        }

        private String _FooterText;
        public String FooterText
        {
            get { return _FooterText; }
            set { _FooterText = value; }
        }

        private String _Footer;
        public String Footer
        {
            get { return _Footer; }
            set { _Footer = value; }
        }

        private String _img1;
        public String img1
        {
            get { return _img1; }
            set { _img1 = value; }
        }
        private String _img2;
        public String img2
        {
            get { return _img2; }
            set { _img2 = value; }
        }
        private String _img3;
        public String img3
        {
            get { return _img3; }
            set { _img3 = value; }
        }
        private String _img4;
        public String img4
        {
            get { return _img4; }
            set { _img4 = value; }
        }

        private String _txt1;
        public String txt1
        {
            get { return _txt1; }
            set { _txt1 = value; }
        }
        private String _txt2;
        public String txt2
        {
            get { return _txt2; }
            set { _txt2 = value; }
        }
        private String _txt3;
        public String txt3
        {
            get { return _txt3; }
            set { _txt3 = value; }
        }
        private String _txt4;
        public String txt4
        {
            get { return _txt4; }
            set { _txt4 = value; }
        }

        private String _lnk1;
        public String lnk1
        {
            get { return _lnk1; }
            set { _lnk1 = value; }
        }
        private String _lnk2;
        public String lnk2
        {
            get { return _lnk2; }
            set { _lnk2 = value; }
        }
        private String _lnk3;
        public String lnk3
        {
            get { return _lnk3; }
            set { _lnk3 = value; }
        }
        private String _lnk4;
        public String lnk4
        {
            get { return _lnk4; }
            set { _lnk4 = value; }
        }

    }
}