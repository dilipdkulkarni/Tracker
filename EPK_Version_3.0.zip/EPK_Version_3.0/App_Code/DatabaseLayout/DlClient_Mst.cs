﻿using System;

namespace DatabaseLayout
{
    public class DlClient_Mst
    {
        private Int32 _ID;
        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private String _Name;
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        private String _UserName;
        public String UserName
        {
            get { return _UserName; }
            set { _UserName = value; }
        }

        private String _Password;
        public String Password
        {
            get { return _Password; }
            set { _Password = value; }
        }

        private Int32 _CM_ID;
        public Int32 CM_ID
        {
            get { return _CM_ID; }
            set { _CM_ID = value; }
        }

        private Int16 _RecState;
        public Int16 RecState
        {
            get { return _RecState; }
            set { _RecState = value; }
        }
        
        private DateTime _CreateDt;
        public DateTime CreateDt
        {
            get { return _CreateDt; }
            set { _CreateDt = value; }
        }

        private Object _LastModifyDt = DBNull.Value;
        public Object LastModifyDt
        {
            get { return _LastModifyDt; }
            set { _LastModifyDt = value; }
        }

        private Int32 _NumUpdates;
        public Int32 NumUpdates
        {
            get { return _NumUpdates; }
            set { _NumUpdates = value; }
        }

        private String _SecQuestion;
        public String SecQuestion
        {
            get { return _SecQuestion; }
            set { _SecQuestion = value; }
        }

        private String _SecAnswer;
        public String SecAnswer
        {
            get { return _SecAnswer; }
            set { _SecAnswer = value; }
        }

        private Int16 _MailActiveFlg;
        public Int16 MailActiveFlg
        {
            get { return _MailActiveFlg; }
            set { _MailActiveFlg = value; }
        }

        private Object _TypeID = DBNull.Value;
        public Object TypeID
        {
            get { return _TypeID; }
            set { _TypeID = value; }
        }

        private Int32 _Accounts;
        public Int32 Accounts
        {
            get { return _Accounts; }
            set { _Accounts = value; }
        }

        private Object _ManagerID = DBNull.Value;
        public Object ManagerID
        {
            get { return _ManagerID; }
            set { _ManagerID = value; }
        }
    }
}