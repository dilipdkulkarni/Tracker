﻿using System;

namespace DatabaseLayout
{
    public class DlEPK_Details
    {
        private Int32 _EM_ID;
        public Int32 EM_ID
        {
            get { return _EM_ID; }
            set { _EM_ID = value; }
        }

        private String _FromName;
        public String FromName
        {
            get { return _FromName; }
            set { _FromName = value; }
        }

        private String _FromMail;
        public String FromMail
        {
            get { return _FromMail; }
            set { _FromMail = value; }
        }

        private String _Subject;
        public String Subject
        {
            get { return _Subject; }
            set { _Subject = value; }
        }

        private String _Body;
        public String Body
        {
            get { return _Body; }
            set { _Body = value; }
        }
    }
}