﻿using System;

namespace DatabaseLayout
{
    public class DlRequest_Dtls
    {
        private Int32 _ID;
        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private Int32 _CM_ID;
        public Int32 CM_ID
        {
            get { return _CM_ID; }
            set { _CM_ID = value; }
        }

        private String _Name;
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        private String _Email;
        public String Email
        {
            get { return _Email; }
            set { _Email = value; }
        }

        private String _Code;
        public String Code
        {
            get { return _Code; }
            set { _Code = value; }
        }

        private DateTime _SentDtm;
        public DateTime SentDtm
        {
            get { return _SentDtm; }
            set { _SentDtm = value; }
        }

        private Int32 _StatusFlg;
        public Int32 StatusFlg
        {
            get { return _StatusFlg; }
            set { _StatusFlg = value; }
        }

        private DateTime _StatusDtm;
        public DateTime StatusDtm
        {
            get { return _StatusDtm; }
            set { _StatusDtm = value; }
        }
    }
}