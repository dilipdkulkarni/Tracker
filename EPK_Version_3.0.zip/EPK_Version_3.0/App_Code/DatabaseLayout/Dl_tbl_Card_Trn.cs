﻿using System;

namespace DatabaseLayout
{
    public class Dl_tbl_Card_Trn
    {
        private Int32 _CM_ID;
        public Int32 CM_ID
        {
            get { return _CM_ID; }
            set { _CM_ID = value; }
        }

        private Int32 _NoOfAccounts;
        public Int32 NoOfAccounts
        {
            get { return _NoOfAccounts; }
            set { _NoOfAccounts = value; }
        }
                
        private String _ct_Type;
        public String ct_Type
        {
            get { return _ct_Type; }
            set { _ct_Type = value; }
        }

        private String _ct_Holder;
        public String ct_Holder
        {
            get { return _ct_Holder; }
            set { _ct_Holder = value; }
        }

        private String _ct_No;
        public String ct_No
        {
            get { return _ct_No; }
            set { _ct_No = value; }
        }

        private String _ct_Name;
        public String ct_Name
        {
            get { return _ct_Name; }
            set { _ct_Name = value; }
        }

        private String _ct_CVV;
        public String ct_CVV
        {
            get { return _ct_CVV; }
            set { _ct_CVV = value; }
        }

        private String _ct_ExpDt;
        public String ct_ExpDt
        {
            get { return _ct_ExpDt; }
            set { _ct_ExpDt = value; }
        }

        private String _StatusDtm;
        public String StatusDtm
        {
            get { return _StatusDtm; }
            set { _StatusDtm = value; }
        }
    }
}
