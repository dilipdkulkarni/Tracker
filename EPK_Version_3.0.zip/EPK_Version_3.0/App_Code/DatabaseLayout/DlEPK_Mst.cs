﻿using System;

namespace DatabaseLayout
{
    public class DlEPK_Mst
    {
        private Int32 _ID;
        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private String _Name;
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        private Int32 _CM_ID;
        public Int32 CM_ID
        {
            get { return _CM_ID; }
            set { _CM_ID = value; }
        }

        private Int32 _RecState;
        public Int32 RecState
        {
            get { return _RecState; }
            set { _RecState = value; }
        }

        private DateTime _CreateDt;
        public DateTime CreateDt
        {
            get { return _CreateDt; }
            set { _CreateDt = value; }
        }

        private DateTime _LastModifyDt;
        public DateTime LastModifyDt
        {
            get { return _LastModifyDt; }
            set { _LastModifyDt = value; }
        }

        private Int32 _NumUpdates;
        public Int32 NumUpdates
        {
            get { return _NumUpdates; }
            set { _NumUpdates = value; }
        }
    }
}