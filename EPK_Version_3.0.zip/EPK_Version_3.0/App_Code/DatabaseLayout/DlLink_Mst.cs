﻿using System;

namespace DatabaseLayout
{
    public class DlLink_Mst
    {
        private Int32 _ID;
        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private String _Name;
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        private String _Url;
        public String Url
        {
            get { return _Url; }
            set { _Url = value; }
        }
               
        private Int32 _EM_ID;
        public Int32 EM_ID
        {
            get { return _EM_ID; }
            set { _EM_ID = value; }
        }
 
        private Int16 _RecState;
        public Int16 RecState
        {
            get { return _RecState; }
            set { _RecState = value; }
        }

        private Int32 _UM_ID;
        public Int32 UM_ID
        {
            get { return _UM_ID; }
            set { _UM_ID = value; }
        }
 
        
    }
}