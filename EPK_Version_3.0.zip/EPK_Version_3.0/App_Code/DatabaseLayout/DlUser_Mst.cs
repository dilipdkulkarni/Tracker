﻿using System;

namespace DatabaseLayout
{
    public class DlUser_Mst
    {
        private Int32 _ID;
        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private String _Name;
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        private String _UserName;
        public String UserName
        {
            get { return _UserName; }
            set { _UserName = value; }
        }

        private String _Password;
        public String Password
        {
            get { return _Password; }
            set { _Password = value; }
        }

        private String _Email;
        public String Email
        {
            get { return _Email; }
            set { _Email = value; }
        }

        private Int16 _RecState;
        public Int16 RecState
        {
            get { return _RecState; }
            set { _RecState = value; }
        }
        
        private DateTime _CreateDt;
        public DateTime CreateDt
        {
            get { return _CreateDt; }
            set { _CreateDt = value; }
        }

        private Object _LastModifyDt = DBNull.Value;
        public Object LastModifyDt
        {
            get { return _LastModifyDt; }
            set { _LastModifyDt = value; }
        }

        private Int32 _NumUpdates;
        public Int32 NumUpdates
        {
            get { return _NumUpdates; }
            set { _NumUpdates = value; }
        }

        private Object _LastLoginDT = DBNull.Value;
        public Object LastLoginDT
        {
            get { return _LastLoginDT; }
            set { _LastLoginDT = value; }
        }

        private String _SecQuestion;
        public String SecQuestion
        {
            get { return _SecQuestion; }
            set { _SecQuestion = value; }
        }

        private String _SecAnswer;
        public String SecAnswer
        {
            get { return _SecAnswer; }
            set { _SecAnswer = value; }
        }

        private Int32 _UTM_ID;
        public Int32 UTM_ID
        {
            get { return _UTM_ID; }
            set { _UTM_ID = value; }
        }
    }
}