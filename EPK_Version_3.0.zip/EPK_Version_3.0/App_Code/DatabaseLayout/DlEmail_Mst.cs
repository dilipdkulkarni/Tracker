﻿using System;

namespace DatabaseLayout
{
    public class DlEmail_Mst
    {
        private Int32 _ID;
        public Int32 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private Int32 _BatchID;
        public Int32 BatchID
        {
            get { return _BatchID; }
            set { _BatchID = value; }
        }

        private String _FromName;
        public String FromName
        {
            get { return _FromName; }
            set { _FromName = value; }
        }

        private String _FromMail;
        public String FromMail
        {
            get { return _FromMail; }
            set { _FromMail = value; }
        }

        private String _ToName;
        public String ToName
        {
            get { return _ToName; }
            set { _ToName = value; }
        }

        private String _ToMail;
        public String ToMail
        {
            get { return _ToMail; }
            set { _ToMail = value; }
        }

        private String _Subject;
        public String Subject
        {
            get { return _Subject; }
            set { _Subject = value; }
        }

        private String _EmailGUID;
        public String EmailGUID
        {
            get { return _EmailGUID; }
            set { _EmailGUID = value; }
        }

        private Int32 _EM_ID;
        public Int32 EM_ID
        {
            get { return _EM_ID; }
            set { _EM_ID = value; }
        }

        private Int32 _RecState;
        public Int32 RecState
        {
            get { return _RecState; }
            set { _RecState = value; }
        }

        private DateTime _CreateDt;
        public DateTime CreateDt
        {
            get { return _CreateDt; }
            set { _CreateDt = value; }
        }

        private Int32 _FwdFlg;
        public Int32 FwdFlg
        {
            get { return _FwdFlg; }
            set { _FwdFlg = value; }
        }

        private Int32 _FwdID;
        public Int32 FwdID
        {
            get { return _FwdID; }
            set { _FwdID = value; }
        }
    }
}