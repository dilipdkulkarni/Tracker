﻿using System;
using System.Web;
using Common;

/// <summary>
/// Summary description for BlLogicLayer
/// </summary>
public class BlLogicLayer
{
    //private string dbConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ev3_web"].ConnectionString;

    public int SaveToDB(String strGUID)
    {
        String strClientIP = null;
        strClientIP = Convert.ToString(HttpContext.Current.Request.UserHostAddress);

        DataMethods dlObject = new DataMethods();
        String spName = null;
        Object[] parameterValues = null;

        spName = "prc_SaveTrn";
        parameterValues = new object[] { strGUID, strClientIP };
        int retVal = dlObject.ExecuteNonQueryMessage(parameterValues, spName);
        return retVal;
    }

    //public void SaveToDB(string key, string strGUID)
    //{
    //    if ((key == null) || (key.Trim().Length == 0))
    //    {
    //        return;
    //    }

    //    string strClientIP = null;
    //    strClientIP = Convert.ToString(HttpContext.Current.Request.UserHostAddress);

    //    string sqlText = string.Format("SELECT TOP 1 DATEDIFF(ss, dateEntered, GETDATE()) FROM EmailTracker WHERE emailGUID = '{0}' and strIPAddress = '{1}' ORDER BY primarykey DESC", strGUID, strClientIP);
    //    SqlCommand cmd = new SqlCommand(sqlText, new SqlConnection(dbConnectionString));
    //    cmd.Connection.Open();
    //    Int32 intDelay = Convert.ToInt32(cmd.ExecuteScalar());
    //    cmd.Connection.Close();

    //    if (intDelay >= 60 | intDelay == 0)
    //    {
    //        sqlText = string.Format("SELECT ID FROM tb_EmailInfo WHERE strGUID = '{0}'", strGUID);
    //        cmd = new SqlCommand(sqlText, new SqlConnection(dbConnectionString));
    //        cmd.Connection.Open();
    //        int intMailID = Convert.ToInt32(cmd.ExecuteScalar());
    //        cmd.Connection.Close();

    //        sqlText = string.Format("INSERT INTO EmailTracker( EPK_Id , emailGUID , emailID , strIPAddress) VALUES ( '{0}', '{1}', '{2}', '{3}' )", key.Replace("'", "''"), strGUID, intMailID, strClientIP);
    //        cmd = new SqlCommand(sqlText, new SqlConnection(dbConnectionString));
    //        cmd.Connection.Open();
    //        cmd.ExecuteNonQuery();
    //        cmd.Connection.Close();
    //    }
    //}
}
