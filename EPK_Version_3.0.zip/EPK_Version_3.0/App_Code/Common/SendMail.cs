﻿using System;
using System.Net.Mail;
using System.Web;

namespace Common
{
    public class SendMail
    {
        private string _mailServer = "smtp.gmail.com";
        private string _mailUrl = "http://localhost:1309/EPK_Version_3.0/";

        /// <summary>
        /// Sends mail using SMTP client
        /// </summary>
        /// <param name="mail">The SMTP server (MailServer) as String</param>
        /// <remarks>It can use the IP of Server also</remarks>
        private void Send(MailMessage mail)
        {
            SmtpClient smtp = new SmtpClient(_mailServer);
            System.Net.NetworkCredential basicAuthenticationInfo = new System.Net.NetworkCredential("satishyesane420@gmail.com", "97638439550");
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = basicAuthenticationInfo;
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }
        // End SendMail

        public void SendActivationCode(String strName, String strMail, String strCode)
        {
            MailMessage objMailMessage = new MailMessage();
            objMailMessage.From = new MailAddress("satishyesane420@gmail.com", "Emailtracker");
            objMailMessage.To.Add(new MailAddress(strMail, strName));
            objMailMessage.Subject = "Activation Code for EPK.";
            String strBody = "<div style='padding:20px;'>Congratulations! you have successfully registered with us. <br /><br /><a href='" + _mailUrl + "Admin/ActivateAccount.aspx?email=" + strMail + "&actCode=" + strCode + "'>Click here</a> to activate your account.</div>";

            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(strBody, null, "text/html");
            objMailMessage.AlternateViews.Add(htmlView);
            Send(objMailMessage);
        }

        public void SendActivationCode4Manager(String strUserName, String strUserMail, String strMail, String strCode)
        {
            MailMessage objMailMessage = new MailMessage();
            objMailMessage.From = new MailAddress("satishyesane420@gmail.com", "Emailtracker");
            objMailMessage.To.Add(new MailAddress(strMail, strUserName));
            objMailMessage.Subject = "Activation Code for EPK.";
            String strBody = "<div style='padding:20px;'>Dear Manager, <br /><div style='padding:20px;'>User " + strUserName + " has successfully registered with us. <br /><br /><a href='" + _mailUrl + "Admin/ActivateAccount.aspx?email=" + strUserMail + "&actCode=" + strCode + "'>Click here</a> to activate the account.</div></div>";

            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(strBody, null, "text/html");
            objMailMessage.AlternateViews.Add(htmlView);
            Send(objMailMessage);
        }

        public void SendResetPwdLink(String strCM_ID, String strName, String strMail)
        {
            MailMessage objMailMessage = new MailMessage();
            objMailMessage.From = new MailAddress("satishyesane420@gmail.com", "Emailtracker");
            objMailMessage.To.Add(new MailAddress(strMail, strName));
            objMailMessage.Subject = "Reset you account password.";
            String strBody = "<div style='padding: 20px;'>This is an automated email, please don&#8217;t reply.<br /><br /><a href='" + _mailUrl + "Admin/ResetPwd.aspx?Id=" + strCM_ID + "'>Click here</a> to reset your password.</div>";

            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(strBody, null, "text/html");
            objMailMessage.AlternateViews.Add(htmlView);
            Send(objMailMessage);
        }

        public void SendActivationConfirm(String strMail)
        {
            MailMessage objMailMessage = new MailMessage();
            objMailMessage.From = new MailAddress("satishyesane420@gmail.com", "Emailtracker");
            objMailMessage.To.Add(new MailAddress(strMail, ""));
            objMailMessage.Subject = "Welcome to EPK.";
            String strBody = "<div style='padding:20px;'>Your account has been activated.</div>";

            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(strBody, null, "text/html");
            objMailMessage.AlternateViews.Add(htmlView);
            Send(objMailMessage);
        }

        public void SendTestEPK(MailMessage objMailMessage)
        {
            Send(objMailMessage);
        }

        public void SendEPK(Object[] obj, String strGUID)
        {
            MailMessage objMailMessage = new MailMessage();
            objMailMessage.From = new MailAddress(obj[1].ToString(), obj[0].ToString());
            objMailMessage.To.Clear();
            objMailMessage.To.Add(new MailAddress(obj[3].ToString(), obj[2].ToString()));
            if (!String.IsNullOrEmpty(Convert.ToString(obj[6])))
                objMailMessage.Bcc.Add(obj[6].ToString());
            objMailMessage.Subject = obj[4].ToString();

            String strBody = obj[5].ToString();
            //strBody += "<br /><img alt='' hspace=0 src='http://trackr.cbil360.com/Admin/SaveToDB.aspx?id=" + strGUID + "' border=0 >";
            strBody += "<br /><img alt='' hspace=0 src='" + _mailUrl + "Admin/SaveToDB.aspx?id=" + strGUID + "' border=0 >";

            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(strBody, null, "text/html");
            objMailMessage.AlternateViews.Add(htmlView);
            Send(objMailMessage);
        }

        public void SendCBIL_EPK(Object[] obj, String strGUID)
        {
            String fromEmail, toEmail, subject;
            fromEmail = obj[0].ToString();
            toEmail = obj[1].ToString();
            subject = obj[2].ToString();

            MailMessage objMailMessage = new MailMessage();
            objMailMessage.From = new MailAddress(fromEmail, fromEmail);
            objMailMessage.To.Add(new MailAddress(toEmail, toEmail));
            objMailMessage.Subject = subject;
            String strBody = obj[3].ToString();
            strBody += "<br /><img alt='' hspace=0 src='" + _mailUrl + "Admin/SaveToDB.aspx?id=" + strGUID + "' border=0 >";

            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(strBody, null, "text/html");
            objMailMessage.AlternateViews.Add(htmlView);
            Send(objMailMessage);
        }

        public void SendRegistrationRequest(String ToName, String ToEmail, String strCode)
        {
            String FromName, FromEmail, Subject, strURL;
            FromName = HttpContext.Current.Session["ClientName"].ToString();
            FromEmail = HttpContext.Current.Session["ClientMail"].ToString();
            Subject = "Registration";

            strURL = HttpContext.Current.Request.Url.AbsoluteUri;
            strURL = strURL.Substring(0, strURL.LastIndexOf('/') + 1);

            MailMessage objMailMessage = new MailMessage();
            objMailMessage.From = new MailAddress(FromEmail, FromName);
            objMailMessage.To.Add(new MailAddress(ToEmail, ToName));
            objMailMessage.Subject = Subject;
            String strBody = "Hello " + ToName + ",<br /><br /> Following is the link for Registration.<br /><br />";
            strBody += "<a href='" + strURL + "Register.aspx?mgrId=" + strCode + "'>Click Here to Register</a>";

            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(strBody, null, "text/html");
            objMailMessage.AlternateViews.Add(htmlView);
            Send(objMailMessage);
        }
    }
}
