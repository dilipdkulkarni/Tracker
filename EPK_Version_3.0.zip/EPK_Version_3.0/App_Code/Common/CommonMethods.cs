﻿using System;
using System.Web;

namespace Common
{
    public class CommonMethods
    {
        //int returnValue;
        //DataMethods dlObject = new DataMethods();
        //string spName;
        //string query;
        //object[] parameterValues;

        public string FilterTextBox(string inputText)
        {
            string returnString = null;
            returnString = inputText.Replace("'", "''");
            returnString = returnString.Trim();
            returnString = HttpContext.Current.Server.HtmlEncode(returnString);

            return returnString;
        }

        public String getString(String str)
        {
            //str = str.Replace("%20", " ");
            //str = str.Replace("%3C", "<");
            //str = str.Replace("%3E", ">");
            str = HttpContext.Current.Server.UrlDecode(str);
            str = str.Replace("\"", "'");
            str = str.Replace("_cke_saved_href", "href");
            str = str.Replace("href='javascript:void(0)", "'");
            str = str.Replace("href=\"javascript:void(0)", "\"");

            String tmp = str;
            String tmp1;
            int indexHref, indexLast;
            while (tmp.LastIndexOf("_cke_saved_href") > 0)
            {
                indexHref = tmp.LastIndexOf("_cke_saved_href");
                tmp1 = tmp.Substring(indexHref);
                indexLast = tmp1.IndexOf("'", tmp1.IndexOf("'") + 1);
                tmp = tmp.Remove(indexHref, indexLast + 1);
            }
            return (tmp);
        }
    }
}
