﻿using System;
using System.Data;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Common
{

    public class DataMethods
    {
        int i;
        int returnValue;

        public string connectionString;
        public DataMethods()
        {
            connectionString = ConfigurationManager.ConnectionStrings["ev3_web"].ConnectionString + ";Pooling=false;Connect Timeout=45;";
        }

        /// <summary>
        /// Method which returns a New Transaction.
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public SqlTransaction getTransaction()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            SqlTransaction transaction = connection.BeginTransaction();
            return transaction;
        }

        /// <summary>
        /// Use for Insert, Update, Delete record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public int ExecuteNonQuery(object[] parameterValues, string spName, ref SqlTransaction transaction)
        {
            if (transaction == null)
            {
                i = SqlHelper.ExecuteNonQuery(connectionString, spName, parameterValues);
            }
            else
            {
                i = SqlHelper.ExecuteNonQuery(transaction, spName, parameterValues);
            }

            if (i > 0)
            {
                returnValue = Convert.ToInt32(parameterValues[0].ToString());
            }
            else
            {
                returnValue = 0;
            }

            return returnValue;
        }

        /// <summary>
        /// Use for Insert, Update, Delete record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public int ExecuteNonQuery(object[] parameterValues, string spName)
        {
            i = SqlHelper.ExecuteNonQuery(connectionString, spName, parameterValues);

            if (i > 0)
                returnValue = Convert.ToInt32(parameterValues[0].ToString());
            else
                returnValue = 0;

            return returnValue;
        }

        /// <summary>
        /// Use for Insert, Update, Delete record for messagebox
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public int ExecuteNonQueryMessage(object[] parameterValues, string spName, ref SqlTransaction transaction)
        {
            if (transaction == null)
            {
                i = SqlHelper.ExecuteNonQuery(connectionString, spName, parameterValues);
            }
            else
            {
                i = SqlHelper.ExecuteNonQuery(transaction, spName, parameterValues);
            }

            returnValue = i;


            return returnValue;
        }

        /// <summary>
        /// Use for Insert, Update, Delete record for messagebox
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public int ExecuteNonQueryMessage(object[] parameterValues, string spName)
        {
            i = SqlHelper.ExecuteNonQuery(connectionString, spName, parameterValues);
            returnValue = i;
            return returnValue;
        }

        /// <summary>
        /// Use for Insert, Update, Delete record without Parameters.
        /// </summary>
        /// <param name="commandType"></param>
        /// <param name="commandText"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public int ExecuteNonQuery(CommandType commandType, string commandText, ref SqlTransaction transaction)
        {
            if (transaction == null)
            {
                i = SqlHelper.ExecuteNonQuery(connectionString, commandType, commandText);
            }
            else
            {
                i = SqlHelper.ExecuteNonQuery(transaction, commandType, commandText);
            }
            returnValue = Convert.ToInt16(i);
            return returnValue;
        }

        /// <summary>
        /// Use for Insert, Update, Delete record without Parameters.
        /// </summary>
        /// <param name="commandType"></param>
        /// <param name="commandText"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public int ExecuteNonQuery(CommandType commandType, string commandText)
        {
            i = SqlHelper.ExecuteNonQuery(connectionString, commandType, commandText);
            returnValue = Convert.ToInt16(i);
            return returnValue;
        }

        /// <summary>
        /// Use for Select Record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public SqlDataReader ExecuteReader(object[] parameterValues, string spName, ref SqlTransaction transaction)
        {
            SqlDataReader dr = default(SqlDataReader);
            if (transaction == null)
            {
                dr = SqlHelper.ExecuteReader(connectionString, spName, parameterValues);
            }
            else
            {
                dr = SqlHelper.ExecuteReader(transaction, spName, parameterValues);
                //Earlier it was connectionString
            }
            return dr;
        }

        /// <summary>
        /// Use for Select Record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public SqlDataReader ExecuteReader(object[] parameterValues, string spName)
        {
            SqlDataReader dr = default(SqlDataReader);
            dr = SqlHelper.ExecuteReader(connectionString, spName, parameterValues);
            return dr;
        }

        /// <summary>
        /// Use for Select Record without Parameters.
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public SqlDataReader ExecuteReader(CommandType commandType, string commandText, ref SqlTransaction transaction)
        {
            SqlDataReader dr = default(SqlDataReader);
            if (transaction == null)
            {
                dr = SqlHelper.ExecuteReader(connectionString, commandType, commandText);
            }
            else
            {
                dr = SqlHelper.ExecuteReader(transaction, commandType, commandText);
                //Earlier it was connectionString
            }
            return dr;
        }

        /// <summary>
        /// Use for Select Record without Parameters.
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public SqlDataReader ExecuteReader(CommandType commandType, string commandText)
        {
            SqlDataReader dr = default(SqlDataReader);
            dr = SqlHelper.ExecuteReader(connectionString, commandType, commandText);
            return dr;
        }

        /// <summary>
        /// Use for Select Record without Parameters.
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public DataSet ExecuteDataset(CommandType commandType, string commandText, ref SqlTransaction transaction)
        {
            DataSet ds = null;
            if (transaction == null)
            {
                ds = SqlHelper.ExecuteDataset(connectionString, commandType, commandText);
            }
            else
            {
                ds = SqlHelper.ExecuteDataset(transaction, commandType, commandText);
                //Earlier it was connectionString
            }
            return ds;
        }

        /// <summary>
        /// Use for Select Record without Parameters.
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public DataSet ExecuteDataset(CommandType commandType, string commandText)
        {
            DataSet ds = null;
            ds = SqlHelper.ExecuteDataset(connectionString, commandType, commandText);
            return ds;
        }

        /// <summary>
        /// Use Dataset for Select Record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public DataSet ExecuteDataset(string spName, object[] parameterValues, ref SqlTransaction transaction)
        {
            DataSet dataSet = new DataSet();
            if (transaction == null)
            {
                dataSet = SqlHelper.ExecuteDataset(connectionString, spName, parameterValues);
            }
            else
            {
                dataSet = SqlHelper.ExecuteDataset(transaction, spName, parameterValues);
                //Earlier it was connectionString
            }
            return dataSet;
        }

        /// <summary>
        /// Use Dataset for Select Record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public DataSet ExecuteDataset(string spName, object[] parameterValues)
        {
            DataSet dataSet = new DataSet();
            dataSet = SqlHelper.ExecuteDataset(connectionString, spName, parameterValues);
            return dataSet;
        }

        /// <summary>
        /// Used to return FirstRow FirstColumn Value.
        /// </summary>
        /// <param name="commandType"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public object ExecuteScalar(CommandType commandType, string spName, object[] parameterValues)
        {
            object returnValue = null;
            returnValue = SqlHelper.ExecuteScalar(connectionString, spName, parameterValues);
            //If i = 0 Then
            //    returnValue = "True"
            //End If
            return returnValue;
        }

        public object ExecuteScalar(CommandType commandType, string spName)
        {
            object returnValue = null;
            returnValue = SqlHelper.ExecuteScalar(connectionString, commandType, spName);
            //If i = 0 Then
            //    returnValue = "True"
            //End If
            return returnValue;
        }

        /// <summary>
        /// Use for count Record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public int ExecuteScalar(object[] parameterValues, string spName, ref SqlTransaction transaction)
        {
            int returnValue;
            returnValue = Convert.ToInt16(SqlHelper.ExecuteScalar(transaction, spName, parameterValues));
            return returnValue;
        }

        /// <summary>
        /// Use for count Record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public int ExecuteScalar(object[] parameterValues, string spName)
        {
            int returnValue;
            returnValue = Convert.ToInt16(SqlHelper.ExecuteScalar(connectionString, spName, parameterValues));
            return returnValue;
        }

        /// <summary>
        /// Use for count Record
        /// </summary>
        /// <param name="parameterValues"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public String ExecuteScalarString(object[] parameterValues, string spName)
        {
            String returnValue;
            returnValue = Convert.ToString(SqlHelper.ExecuteScalar(connectionString, spName, parameterValues));
            return returnValue;
        }
    }

}
